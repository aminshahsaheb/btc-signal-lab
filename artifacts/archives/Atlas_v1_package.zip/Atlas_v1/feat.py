"""Causal feature + label engine for the Move-Onset Atlas (see PLAN.md, PLAN_ERRATA.md).
compute(df) returns everything at D-points (bars whose minute == 55, decision at the full UTC hour).
Nothing here looks beyond bar i when producing the feature at D-point i (verified by test_causal.py);
labels are the only forward-looking quantities and live in labels()."""
import numpy as np, pandas as pd
from zoneinfo import ZoneInfo

def roll(x, n, how):
    s = pd.Series(x)
    r = s.rolling(n)
    return getattr(r, how)().to_numpy()

def dpoints(ts):
    return np.where(ts.minute.to_numpy() == 55)[0]

def labels(c, idx, LABELS):
    """first-breach direction on closes, tolerance 1e-12; invalid -> -9."""
    N = len(c); lc = np.log(c); out = {}
    base = lc[idx]
    for name, (th, H) in LABELS.items():
        thr = np.log1p(th) - 1e-12
        d = np.zeros(len(idx), np.int8); tt = np.zeros(len(idx), np.int32)
        valid = idx + H <= N - 1
        out[name] = [d, tt, valid]
    Hmax = max(h for _, h in LABELS.values())
    for k in range(1, Hmax + 1):
        j = np.minimum(idx + k, N - 1)
        r = lc[j] - base
        for name, (th, H) in LABELS.items():
            if k > H: continue
            d, tt, valid = out[name]
            thr = np.log1p(th) - 1e-12
            hit = (d == 0) & (np.abs(r) >= thr) & valid
            d[hit] = np.sign(r[hit]).astype(np.int8); tt[hit] = k
    res = {}
    for name in LABELS:
        d, tt, valid = out[name]
        d = d.copy(); d[~valid] = -9
        res[name] = d; res[name + "_t"] = tt
    return res

def _event_cells(dts):
    """event-aligned D-point cells (offsets -1h,0,+1h around each event). dts: DatetimeIndex UTC of decision times."""
    cells = {}
    d0 = dts[0].normalize() - pd.Timedelta("2D"); d1 = dts[-1].normalize() + pd.Timedelta("2D")
    days = pd.date_range(d0.tz_localize(None), d1.tz_localize(None), freq="D")
    def local(day, hh, mm, tz):
        return pd.Timestamp(year=day.year, month=day.month, day=day.day, hour=hh, minute=mm, tz=ZoneInfo(tz)).tz_convert("UTC")
    ev = {"TOKYO": [], "LONDON": [], "NYOPEN": [], "NYCLOSE": [], "CMEREOPEN": [], "DERIBIT": [], "FUNDING": []}
    for day in days:
        wd = day.weekday()
        if wd < 5:
            ev["TOKYO"].append(local(day, 9, 0, "Asia/Tokyo"))
            ev["LONDON"].append(local(day, 8, 0, "Europe/London"))
            ev["NYOPEN"].append(local(day, 9, 30, "America/New_York"))
            ev["NYCLOSE"].append(local(day, 16, 0, "America/New_York"))
        if wd in (6, 0, 1, 2, 3):   # Sun..Thu 17:00 CT reopen
            ev["CMEREOPEN"].append(local(day, 17, 0, "America/Chicago"))
        if wd == 4:
            ev["DERIBIT"].append(pd.Timestamp(year=day.year, month=day.month, day=day.day, hour=8, tz="UTC"))
        for hh in (0, 8, 16):
            ev["FUNDING"].append(pd.Timestamp(year=day.year, month=day.month, day=day.day, hour=hh, tz="UTC"))
    dv = dts.to_numpy()
    for name, lst in ev.items():
        E = pd.DatetimeIndex(lst).tz_convert("UTC").to_numpy()
        E = E[(E >= dv[0]) & (E <= dv[-1])]
        for off, tag in ((-1, "m1"), (0, "z0"), (1, "p1")):
            pos = np.searchsorted(dv, E) + off
            pos = pos[(pos >= 0) & (pos < len(dv))]
            # drop events outside the data span
            m = np.zeros(len(dv), bool); m[pos] = True
            cells[f"EV_{name}_{tag}"] = m
    return cells

def fvg_cells(hc_o, hc_h, hc_l, hc_c, minsize=0.002, life=48):
    nH = len(hc_h)
    fb = np.zeros(nH, bool); fs = np.zeros(nH, bool); rb = np.zeros(nH, bool); rs = np.zeros(nH, bool)
    bull = []; bear = []   # zones: [formed_hour, lo, hi]
    for i in range(nH):
        # 1) touches / mitigation using hour i (zones formed before hour i)
        if bull:
            bull = [z for z in bull if i - z[0] <= life]
            touched = [z for z in bull if hc_l[i] <= z[2]]
            if touched:
                latest = max(bull, key=lambda z: z[0])
                if latest in touched: rb[i] = True
                bull = [z for z in bull if z not in touched]
            bull = [z for z in bull if not (hc_c[i] < z[1])]
        if bear:
            bear = [z for z in bear if i - z[0] <= life]
            touched = [z for z in bear if hc_h[i] >= z[1]]
            if touched:
                latest = max(bear, key=lambda z: z[0])
                if latest in touched: rs[i] = True
                bear = [z for z in bear if z not in touched]
            bear = [z for z in bear if not (hc_c[i] > z[2])]
        # 2) new FVG completed at end of hour i
        if i >= 2:
            if hc_l[i] > hc_h[i - 2] and (hc_l[i] - hc_h[i - 2]) / hc_c[i - 1] >= minsize:
                fb[i] = True; bull.append([i, hc_h[i - 2], hc_l[i]])
            if hc_h[i] < hc_l[i - 2] and (hc_l[i - 2] - hc_h[i]) / hc_c[i - 1] >= minsize:
                fs[i] = True; bear.append([i, hc_h[i], hc_l[i - 2]])
    return {"FVG_FORM_BULL": fb, "FVG_FORM_BEAR": fs, "FVG_RETEST_BULL": rb, "FVG_RETEST_BEAR": rs}

def compute(df):
    """Returns dict with idx, decision timestamps and all raw features/events at D-points."""
    ts = df.index
    o = df.open.to_numpy(float); h = df.high.to_numpy(float); l = df.low.to_numpy(float)
    c = df.close.to_numpy(float); v = df.volume.to_numpy(float); tb = df.taker_buy_base.to_numpy(float)
    N = len(df)
    idx = dpoints(ts)
    dts = ts[idx] + pd.Timedelta("5min")
    F = {}
    r5 = np.r_[np.nan, np.diff(np.log(c))]
    ss = r5 ** 2
    # ranges
    def rng(n): return (roll(h, n, "max") - roll(l, n, "min")) / c
    range12 = rng(12); range288 = rng(288)
    with np.errstate(all="ignore"):
        F["ln_range12"] = np.log(range12)[idx]; F["ln_range288"] = np.log(range288)[idx]
        F["compress"] = (np.log(range12) - np.log(range288))[idx]
        ss12 = roll(ss, 12, "sum"); ss288 = roll(ss, 288, "sum")
        vr = (ss12 / 12) / (ss288 / 288); vr[vr <= 0] = np.nan
        F["varratio"] = np.log(vr)[idx]
        # NR24 / WR24
        k = np.arange(24) * 12
        pos = idx[:, None] - k[None, :]
        okp = pos[:, -1] >= 0
        mat = range12[np.maximum(pos, 0)]
        mat[~okp] = np.nan
        cur = mat[:, 0]
        F["NR24"] = (cur <= np.nanmin(mat, axis=1)) & okp & ~np.isnan(mat).any(axis=1)
        F["WR24"] = (cur >= np.nanmax(mat, axis=1)) & okp & ~np.isnan(mat).any(axis=1)
        # position in range
        for name, n in (("pos24", 288), ("pos7d", 2016)):
            mx = roll(h, n, "max"); mn = roll(l, n, "min"); den = mx - mn
            p = (c - mn) / den; p[den <= 0] = np.nan
            F[name] = p[idx]
        # day / week open displacement
        minute_of_day = (ts.hour.to_numpy() * 60 + ts.minute.to_numpy()) // 5
        dstart = np.arange(N) - minute_of_day
        F["dayopen_z"] = (np.log(c / o[dstart]) / np.sqrt(ss288))[idx]
        wstart = np.arange(N) - ts.dayofweek.to_numpy() * 288 - minute_of_day
        wvalid = wstart >= 0
        wo = np.where(wvalid, o[np.maximum(wstart, 0)], np.nan)
        F["weekopen_z"] = (np.log(c / wo) / np.sqrt(ss288))[idx]
        # round level proximity
        F["round_dist"] = (np.abs(c - 5000 * np.round(c / 5000)) / c)[idx]
        # breaks / sweeps
        for Nn in (48, 288, 2016, 8640):
            pmax = pd.Series(h).rolling(Nn - 11).max().shift(12).to_numpy()   # bars t-N..t-12
            pmin = pd.Series(l).rolling(Nn - 11).min().shift(12).to_numpy()
            hi12 = roll(h, 12, "max"); lo12 = roll(l, 12, "min")
            F[f"BREAK_UP_{Nn}"] = (c > pmax)[idx]
            F[f"BREAK_DN_{Nn}"] = (c < pmin)[idx]
            F[f"SWEEP_UP_{Nn}"] = ((hi12 > pmax) & (c <= pmax))[idx]
            F[f"SWEEP_DN_{Nn}"] = ((lo12 < pmin) & (c >= pmin))[idx]
        lo288 = roll(l, 288, "min"); hi288 = roll(h, 288, "max")
        F["BOUNCE_UP"] = ((c >= 1.01 * lo288) & (roll(l, 24, "min") == lo288))[idx]
        F["BOUNCE_DN"] = ((c <= 0.99 * hi288) & (roll(h, 24, "max") == hi288))[idx]
        # context returns
        sig = pd.Series(r5).rolling(2016).std().to_numpy()
        lc = np.log(c)
        for kk in (12, 48, 288, 2016):
            ret = lc - np.r_[np.full(kk, np.nan), lc[:-kk]]
            F[f"ctx{kk}"] = (ret / (sig * np.sqrt(kk)))[idx]
        # flow
        V12 = roll(v, 12, "sum")
        shifts = np.arange(1, 9) * 2016
        pv = idx[:, None] - shifts[None, :]
        okw = pv[:, -1] >= 0
        medV = np.nanmedian(np.where(pv >= 0, V12[np.maximum(pv, 0)], np.nan), axis=1)
        medR = np.nanmedian(np.where(pv >= 0, range12[np.maximum(pv, 0)], np.nan), axis=1)
        VRr = np.log(V12[idx] / medV); VRr[~okw] = np.nan; VRr[~np.isfinite(VRr)] = np.nan
        F["VR"] = VRr
        absi = VRr - np.log(range12[idx] / medR); absi[~np.isfinite(absi)] = np.nan
        F["ABS"] = absi
        for kk in (12, 48, 288):
            sv = roll(v, kk, "sum"); stb = roll(tb, kk, "sum")
            ti = (2 * stb - sv) / sv; ti[sv <= 0] = np.nan
            F[f"TI{kk}"] = ti[idx]
    # FVG on hourly candles (D-point j <-> hour j)
    assert N % 12 == 0 or True
    nH = len(idx)
    hc_o = o[idx - 11]; hc_c = c[idx]
    hc_h = np.array([h[i - 11:i + 1].max() for i in idx]); hc_l = np.array([l[i - 11:i + 1].min() for i in idx])
    fv = fvg_cells(hc_o, hc_h, hc_l, hc_c)
    F.update(fv)
    # calendar
    F["hour"] = dts.hour.to_numpy(); F["dow"] = dts.dayofweek.to_numpy(); F["year"] = dts.year.to_numpy()
    F["doy"] = dts.dayofyear.to_numpy()
    F["block"] = F["year"] * 100 + (F["doy"] - 1) // 7
    F["dts_ns"] = dts.as_unit("ns").asi8   # pandas 3 default unit is us -> force ns
    ev = _event_cells(dts)
    F.update({k: v for k, v in ev.items()})
    F["idx"] = idx
    return F
