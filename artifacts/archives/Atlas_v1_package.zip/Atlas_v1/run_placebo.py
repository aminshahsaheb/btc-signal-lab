import numpy as np, pandas as pd, time, pickle
import common, stats_core as sc
common.check_plan()
A = sc.Atlas(); n = A.N; rng = np.random.default_rng(20261025)
fam = A.meta.family.to_numpy(); kind = A.meta.kind.to_numpy()
masks = {"CAL_hd": (kind == "hd"), "OTHER": (kind != "hd") & (fam != "CALEV")}
NP = 300; t0 = time.time()
zs = {name: [] for name in masks}   # per draw: dict outcome -> z array
for draw in range(NP):
    wk = int(rng.integers(8, 271)); k_week = (168 * wk) % n
    while True:
        k_hr = int(rng.integers(200, n - 200))
        if k_hr % 24 != 0: break
    for name, k in (("OTHER", k_week), ("CAL_hd", k_hr)):
        o = A.run(sc.shifted(A.labs, k))
        zs[name].append({key: r["z"].copy() for key, r in o.items()})
    if draw % 50 == 0: print(draw, round(time.time() - t0), "s", flush=True)
pickle.dump(zs, open("placebo_z.pkl", "wb"))
print("done", round(time.time() - t0), "s")
