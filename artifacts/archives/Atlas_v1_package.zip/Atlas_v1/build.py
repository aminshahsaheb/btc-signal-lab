import numpy as np, pandas as pd, scipy.sparse as sp, json, time, warnings
import common, feat
warnings.filterwarnings("ignore")
PH = common.check_plan(); print("plan", PH)
t0 = time.time()
df = common.load()
F = feat.compute(df)
print("features", round(time.time() - t0, 1), "s;  D-points", len(F["idx"]))
c = df.close.to_numpy(float)
lab = feat.labels(c, F["idx"], common.LABELS)
dts = pd.DatetimeIndex(pd.to_datetime(F["dts_ns"], utc=True))
disc = np.asarray(dts < pd.Timestamp("2024-01-01", tz="UTC"))
conf = np.asarray((dts >= pd.Timestamp("2024-01-01", tz="UTC")) & (dts < pd.Timestamp("2025-01-07", tz="UTC")))
split = np.where(disc, 0, np.where(conf, 1, 2)).astype(np.int8)
n = len(dts)
cells = []   # (id, family, kind, mask)
def add(i, fam, kind, mask): cells.append((i, fam, kind, np.asarray(mask, bool)))
edges = {}
def qbins(name, fam, fixed=None):
    x = F[name]
    if fixed is None:
        e = np.nanquantile(x[disc & np.isfinite(x)], [.2, .4, .6, .8])
    else: e = np.array(fixed)
    edges[name] = [float(v) for v in e]
    b = np.digitize(x, e); ok = np.isfinite(x)
    for k in range(5): add(f"{name}_b{k}", fam, "bin", ok & (b == k))
for hh in range(24): add(f"C_H{hh:02d}", "CAL", "hd", F["hour"] == hh)
for d in range(7): add(f"C_D{d}", "CAL", "hd", F["dow"] == d)
for k in sorted(k for k in F if k.startswith("EV_")): add(k, "CALEV", "ev", F[k])
for nm in ("ln_range12", "ln_range288", "compress", "varratio"): qbins(nm, "VOL")
add("NR24", "VOL", "event", F["NR24"]); add("WR24", "VOL", "event", F["WR24"])
qbins("pos24", "LOC", [.2, .4, .6, .8]); qbins("pos7d", "LOC", [.2, .4, .6, .8])
qbins("dayopen_z", "LOC"); qbins("weekopen_z", "LOC")
x = F["round_dist"]
add("round_b0", "LOC", "bin", x <= 0.0025); add("round_b1", "LOC", "bin", (x > 0.0025) & (x <= 0.01)); add("round_b2", "LOC", "bin", x > 0.01)
for Nn in (48, 288, 2016, 8640):
    for t in ("BREAK_UP", "BREAK_DN", "SWEEP_UP", "SWEEP_DN"): add(f"{t}_{Nn}", "LOC", "event", F[f"{t}_{Nn}"])
add("BOUNCE_UP", "LOC", "event", F["BOUNCE_UP"]); add("BOUNCE_DN", "LOC", "event", F["BOUNCE_DN"])
for kk in (12, 48, 288, 2016): qbins(f"ctx{kk}", "CTX")
for nm in ("VR", "TI12", "TI48", "TI288", "ABS"): qbins(nm, "FLOW")
for nm in ("FVG_FORM_BULL", "FVG_FORM_BEAR", "FVG_RETEST_BULL", "FVG_RETEST_BEAR"): add(nm, "FVG", "event", F[nm])
meta = pd.DataFrame([(i, f, k, int(m.sum())) for i, f, k, m in cells], columns=["cell", "family", "kind", "n_points"])
print(meta.groupby("family").agg(cells=("cell", "count")).T.to_string()); print("total cells", len(meta))
M = sp.csr_matrix(np.column_stack([m for *_, m in cells]).astype(np.int8))
sp.save_npz("cellmat.npz", M)
meta.to_csv("cells_meta.csv", index=False)
raw = {k: v for k, v in F.items() if k not in ("idx",)}
np.savez_compressed("base.npz", idx=F["idx"], split=split, hour=F["hour"], dow=F["dow"], year=F["year"], block=F["block"], dts_ns=F["dts_ns"],
                    L1=lab["L1"], L2=lab["L2"], L3=lab["L3"], L1_t=lab["L1_t"], L2_t=lab["L2_t"], L3_t=lab["L3_t"],
                    **{f"f_{k}": v for k, v in F.items() if k in ("ln_range12","ln_range288","compress","varratio","pos24","pos7d","dayopen_z","weekopen_z","round_dist","ctx12","ctx48","ctx288","ctx2016","VR","ABS","TI12","TI48","TI288")})
json.dump(edges, open("edges.json", "w"), indent=1)
print("saved", round(time.time() - t0, 1), "s")
for L in ("L1", "L2", "L3"):
    d = lab[L]; v = d != -9
    print(L, "valid", int(v.sum()), "UP", int((d == 1).sum()), "DOWN", int((d == -1).sum()), "NONE", int((d == 0).sum()), "move rate", round(float((d[v] != 0).mean()), 4))
