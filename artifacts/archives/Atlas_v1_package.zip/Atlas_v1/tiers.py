import numpy as np, pandas as pd, pickle
from scipy.stats import norm
import common
common.check_plan()
res = pd.read_csv("atlas_all_tests.csv")
zs = pickle.load(open("placebo_z.pkl", "rb"))
meta = pd.read_csv("cells_meta.csv"); fam = meta.family.to_numpy(); kind = meta.kind.to_numpy()
res["type"] = np.where(res.outcome.str.startswith("MOVE"), "MOVE", "DIR")
ntests = {f: int((fam == f).sum()) * 6 for f in np.unique(fam)}
rows = []; pool = {}
for f in ["CAL", "VOL", "LOC", "CTX", "FLOW", "FVG"]:
    key = "CAL_hd" if f == "CAL" else "OTHER"
    cm = (fam == f) & (kind == "hd" if f == "CAL" else fam == f)
    for typ in ("MOVE", "DIR"):
        outs = [o for o in zs[key][0] if o.startswith(typ)]
        mx = []; allz = []
        for dr in zs[key]:
            zz = np.concatenate([np.abs(dr[o][cm]) for o in outs]); zz = zz[np.isfinite(zz)]
            allz.append(zz); mx.append(zz.max() if len(zz) else np.nan)
        allz = np.concatenate(allz); mx = np.array(mx)
        zb = norm.isf(0.025 / ntests[f])
        pool[(f, typ)] = np.sort(allz)
        rows.append(dict(family=f, type=typ, placebo_draws=len(mx), placebo_sd_z=float(np.std(allz)), placebo_mean_maxabsz=float(np.nanmean(mx)),
                         placebo_p95_maxabsz=float(np.nanpercentile(mx, 95)), placebo_max_maxabsz=float(np.nanmax(mx)), bonf_z=float(zb),
                         frac_draws_exceed_bonf=float(np.mean(mx >= zb)), z_crit=float(zb if (f == "CAL" and typ == "MOVE") else max(zb, np.nanpercentile(mx, 95))), tests_in_family=ntests[f],
                         note=("placebo invalid for hour/dow MOVE cells (a time shift relocates the clock effect) -> Bonferroni only" if (f == "CAL" and typ == "MOVE") else "")))
ps = pd.DataFrame(rows); ps.to_csv("placebo_summary.csv", index=False)
print(ps.round(3).to_string(index=False))
# empirical p, BH
zc = {(r.family, r.type): r.z_crit for r in ps.itertuples()}
res["z_crit"] = [zc.get((f, t), np.nan) for f, t in zip(res.family, res.type)]
pe = np.full(len(res), np.nan)
for i, r in enumerate(res.itertuples()):
    if (r.family, r.type) in pool and np.isfinite(r.z):
        arr = pool[(r.family, r.type)]; k = len(arr) - np.searchsorted(arr, abs(r.z), side="left")
        pe[i] = (k + 1) / (len(arr) + 1)
res["p_emp"] = pe
m = np.isfinite(res.p_emp.to_numpy()); order = np.argsort(res.p_emp.to_numpy()[m]); pm = res.p_emp.to_numpy()[m][order]; nT = len(pm)
q = np.empty(nT); q[order] = np.minimum.accumulate((pm * nT / (np.arange(nT) + 1))[::-1])[::-1]
res["q_bh"] = np.nan; res.loc[m, "q_bh"] = q
mat = np.where(res.type == "MOVE", (res.lift >= 1.25) | (res.lift <= 0.80), res.pp.abs() >= 0.03)
res["material"] = mat
eligY = res.n_elig_y; agY = res.n_agree_y
tierA = (res.z.abs() >= res.z_crit) & res.material & (eligY >= 5) & (agY >= eligY - 1) & (res.n_agree_s == res.n_elig_s) & (res.family != "CALEV")
tierB = (res.q_bh < 0.05) & res.material & (eligY >= 3) & (agY >= np.ceil(2 / 3 * eligY)) & (res.family != "CALEV")
res["tier"] = np.where(tierA, "A", np.where(tierB, "B", np.where(res.family == "CALEV", "report-only", "-")))
res.to_csv("atlas_tiers.csv", index=False)
print(res.groupby(["family", "type", "tier"]).size().unstack(fill_value=0).to_string())
