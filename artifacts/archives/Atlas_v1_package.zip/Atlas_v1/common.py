import hashlib, os, numpy as np, pandas as pd
HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, "..", "pkg_data.csv")
PLAN_SHA = "74c4e0a4f11a6a7519fff866fcca6e61a26a292945613ebd10a5b0f2bba9c5da"
ERR_SHA = "c71b2e5261ac8643b0bc41a2a4e6d8368aff40a13a2b7c9659fcf56f7cf44549"
def sha(path): return hashlib.sha256(open(path, "rb").read()).hexdigest()
def check_plan():
    assert sha(os.path.join(HERE, "PLAN.md")) == PLAN_SHA, "PLAN.md changed after lock!"
    lock = open(os.path.join(HERE, "PLAN.sha256")).read().split()
    assert PLAN_SHA in lock, "PLAN.sha256 lock mismatch"
    assert sha(os.path.join(HERE, "PLAN_ERRATA.md")) == ERR_SHA, "PLAN_ERRATA.md changed after lock!"
    return PLAN_SHA[:12]
LABELS = {"L1": (0.01, 24), "L2": (0.02, 96), "L3": (0.03, 288)}
def load():
    df = pd.read_csv(DATA, parse_dates=["timestamp"]).set_index("timestamp")
    assert len(df) == 602208 and sha(DATA).startswith("0bea138cc96dfec0")
    return df
