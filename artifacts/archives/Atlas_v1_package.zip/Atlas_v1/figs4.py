import numpy as np, pandas as pd, warnings
from figstyle import *
import common
warnings.filterwarnings("ignore"); common.check_plan()
df = common.load(); o = df.open.to_numpy(float); h = df.high.to_numpy(float); l = df.low.to_numpy(float); c = df.close.to_numpy(float)
G = pd.read_csv("D7_gallery_events.csv"); b = np.load("base.npz"); idx = b["idx"]
binlab = lambda v, hi: "—" if pd.isna(v) else f"{int(v)}/5"
for typ, col in (("UP", UPC), ("DOWN", DNC)):
    g = G[G["dir"] == typ].reset_index(drop=True)
    fig, axs = plt.subplots(4, 3, figsize=(15, 15.5)); fig.subplots_adjust(hspace=0.5, wspace=0.18, top=0.92)
    for k, (ax, r) in enumerate(zip(axs.ravel(), g.itertuples())):
        i0 = idx[r.j]; a, z = i0 - 288, i0 + 288
        x = (np.arange(a, z + 1) - i0) / 12
        base = c[i0]
        oo, hh, ll, cc = [(arr[a:z + 1] / base - 1) * 100 for arr in (o, h, l, c)]
        up = cc >= oo
        ax.axvspan(0, 24, color=GRID, alpha=0.55, lw=0)
        ax.vlines(x, ll, hh, color=np.where(up, UPC, DNC), lw=0.7)
        ax.bar(x, np.abs(cc - oo) + 1e-4, bottom=np.minimum(oo, cc), width=1 / 12 * 0.8, color=np.where(up, UPC, DNC), lw=0)
        ax.axvline(0, color=INK, lw=1); ax.axhline(0, color=AXIS, lw=0.8)
        ax.set_xlim(-24, 24); ax.set_xticks([-24, -12, 0, 12, 24]); ax.tick_params(labelsize=8.5)
        ts_ = pd.Timestamp(r.ts)
        ax.set_title(f"{ts_.strftime('%a %Y-%m-%d %H:%M')} UTC  ·  {'+' if typ=='UP' else '−'}{r.exc24_pct:.1f}% in 24 h", fontsize=10, pad=15)
        ax.text(0.0, 1.015, f"range {binlab(r.range12_bin,1)} · volume {binlab(r.VR_bin,1)} · prior 4 h {binlab(r.ctx48_bin,1)} · taker {binlab(r.TI48_bin,1)} · pos in 24 h {binlab(r.pos24_bin,1)}", transform=ax.transAxes, fontsize=7.8, color=INK2, va="bottom")
        if k % 3 == 0: ax.set_ylabel("% vs decision price", fontsize=9)
        if k >= 9: ax.set_xlabel("hours from decision (marked line)", fontsize=9)
    fig.suptitle(f"The 12 biggest {typ} impulses (vs. normal volatility), 5-minute candles, ±24 h around the start", x=0.01, ha="left", fontsize=13.5, fontweight="semibold", y=0.955)
    note(fig, "Selected by hindsight from 2%-swings (largest 24 h excursion in units of normal 24 h volatility, ≥24 h apart). Bars under each chart: where that state ranked among all hours (1/5 = lowest 20%, 5/5 = highest 20%; '—' = volume baseline not yet available, early 2021). Among the 12 UP starts the prior 4 h was in the lowest 20% in 9 (lowest 40% in all 12) and the start sat in the lowest fifth of the 24 h range in 9; the 12 DOWN starts mirror it (prior 4 h in the highest 20% in 9, highest 40% in all). That is how swing points are defined (an extreme after a run), so the same picture is NOT a usable live signal (see F08).", y=0.065)
    save(fig, f"F12_gallery_{typ.lower()}")
