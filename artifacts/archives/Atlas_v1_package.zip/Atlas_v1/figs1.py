import numpy as np, pandas as pd, json, warnings
from figstyle import *
import common
warnings.filterwarnings("ignore"); common.check_plan()
df = common.load(); ts = df.index
b = np.load("base.npz"); idx = b["idx"]; dts = pd.DatetimeIndex(pd.to_datetime(b["dts_ns"], utc=True))
T = pd.read_csv("atlas_tiers.csv")
# ---------- F1 whole history map
hr = df["close"].resample("1h").last()
dr = (df["high"].resample("1D").max() / df["low"].resample("1D").min() - 1) * 100
pv = pd.read_csv("D4_pivots_5pct.csv"); pv["ts"] = pd.to_datetime(pv.ts, utc=True)
fig = plt.figure(figsize=(15, 13))
outer = fig.add_gridspec(3, 2, hspace=0.32, wspace=0.12)
for k, y in enumerate(range(2021, 2027)):
    inner = outer[k // 2, k % 2].subgridspec(2, 1, height_ratios=[3.2, 1], hspace=0.06)
    ax = fig.add_subplot(inner[0]); ax2 = fig.add_subplot(inner[1], sharex=ax)
    s = hr[hr.index.year == y]
    ax.plot(s.index, s.values, color=INK2, lw=1.0); ax.set_yscale("log")
    p = pv[pv.ts.dt.year == y]
    lo = p[p.type == -1]; hi = p[p.type == 1]
    ax.scatter(lo.ts, hr.reindex(lo.ts).values, marker="^", s=34, color=UPC, edgecolor=SURF, linewidth=1.2, zorder=5, label="start of a ≥5% up-leg")
    ax.scatter(hi.ts, hr.reindex(hi.ts).values, marker="v", s=34, color=DNC, edgecolor=SURF, linewidth=1.2, zorder=5, label="start of a ≥5% down-leg")
    ax.set_title(f"{y}" + ("  (to Sep 22)" if y == 2026 else ""), fontsize=11)
    ax.tick_params(labelbottom=False); lo_, hi_ = s.min(), s.max(); tk = [t_ for t_ in (15000, 20000, 30000, 40000, 50000, 70000, 100000, 120000) if lo_ * 0.9 <= t_ <= hi_ * 1.1]; ax.set_yticks(tk); ax.yaxis.set_major_formatter(matplotlib.ticker.FuncFormatter(lambda v, _: f"{v/1000:.0f}K")); ax.yaxis.set_minor_formatter(matplotlib.ticker.NullFormatter())
    d = dr[dr.index.year == y]
    ax2.bar(d.index, d.values, width=1.0, color=MUTED, lw=0); ax2.set_ylim(0, 16); ax2.set_ylabel("daily\nrange %", fontsize=8)
    ax2.axhline(5, color=ORANGE, lw=0.8)
    import matplotlib.dates as mdates
    ax2.xaxis.set_major_locator(mdates.MonthLocator(interval=3)); ax2.xaxis.set_major_formatter(mdates.DateFormatter("%b"))
    if k == 0: h_, l_ = ax.get_legend_handles_labels()
fig.legend(h_, l_, loc="lower center", ncol=2, fontsize=10, bbox_to_anchor=(0.5, 0.062))
fig.suptitle("Whole history, 2021 → Sep 2026: price (log scale), where ≥5% legs began, and each day's range", x=0.01, ha="left", fontsize=13, fontweight="semibold", y=0.93)
note(fig, "Triangles are placed in hindsight (a pivot is only known after a ≥5% reversal; median lag ≈ 21–23 h). Orange line = 5% daily range. BTCUSDT perp (Binance USD-M), hourly closes.", y=0.048)
save(fig, "F01_history_map")
# ---------- F2 calendar heatmaps (hour x weekday), year-adjusted
hour = b["hour"]; dow = b["dow"]; year = b["year"]; lab = b["L2"]; v = lab != -9
y = ((lab != 0) & v).astype(float)
rate_y = pd.Series(y[v]).groupby(year[v]).mean(); e = rate_y.reindex(year).to_numpy()
K = np.zeros((7, 24)); E = np.zeros((7, 24)); U = np.zeros((7, 24)); Ev = np.zeros((7, 24)); B = np.zeros((7, 24))
up = ((lab == 1) & v).astype(float); evm = ((lab != 0) & v)
share_y = pd.Series(up[evm]).groupby(year[evm]).mean().reindex(year).to_numpy()
for d_ in range(7):
    for h_ in range(24):
        m = v & (dow == d_) & (hour == h_)
        K[d_, h_] = y[m].sum(); E[d_, h_] = e[m].sum()
        m2 = evm & (dow == d_) & (hour == h_); U[d_, h_] = up[m2].sum(); Ev[d_, h_] = m2.sum(); B[d_, h_] = share_y[m2].sum()
lift = K / E; pp = (U - B) / np.maximum(Ev, 1) * 100
from matplotlib.colors import LinearSegmentedColormap, TwoSlopeNorm
seq = LinearSegmentedColormap.from_list("seq", ["#cde2fb", "#86b6ef", "#2a78d6", "#184f95", "#0d366b"])
div = LinearSegmentedColormap.from_list("div", [ORANGE, "#f0efec", BLUE])
fig, axs = plt.subplots(1, 2, figsize=(15, 4.6))
dn = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
im = axs[0].imshow(lift, aspect="auto", cmap=seq, vmin=0.2, vmax=1.9)
axs[0].set_title("When do ≥2% moves start? (lift vs. that year's average)")
for a in axs: a.grid(False); a.set_yticks(range(7)); a.set_yticklabels(dn); a.set_xticks(range(0, 24, 2)); a.set_xlabel("UTC hour of decision (data up to this hour's start)")
for d_ in range(7):
    for h_ in range(24):
        if lift[d_, h_] >= 1.5 or lift[d_, h_] <= 0.4: axs[0].text(h_, d_, f"{lift[d_, h_]:.1f}", ha="center", va="center", fontsize=7, color="white" if lift[d_, h_] >= 1.5 else INK)
cb = fig.colorbar(im, ax=axs[0], fraction=0.03, pad=0.01); cb.set_label("lift (1.0 = typical)")
im2 = axs[1].imshow(pp, aspect="auto", cmap=div, vmin=-15, vmax=15)
axs[1].set_title("Which way? (up-share minus year baseline)")
cb2 = fig.colorbar(im2, ax=axs[1], fraction=0.03, pad=0.01); cb2.set_label("percentage points  (blue = more UP, orange = more DOWN)")
note(fig, "Left: the clock matters a lot (Mon–Fri 08–16 UTC ≈ 1.5–1.7×; Sat ≈ 0.3–0.5×; Sunday evening ramps up). Right: each cell holds only ~20–40 events (SE ≈ ±8–10 pp), so most colour is noise; the only row-level lean (Thu ≈ −6 pp, Wed ≈ +5 pp) has |z| ≈ 2–2.6, below the corrected threshold 3.6. Hourly decision points 2021–2026.", y=0.0)
save(fig, "F02_calendar_heatmaps")
# ---------- F3 hour-of-day variance share, US summer vs winter
t = pd.read_csv("D2_hour_share_of_variance.csv")
fig, ax = plt.subplots(figsize=(11, 4.2))
ax.plot(t.utc_hour, t.usSummer * 100, color=ORANGE, label="US summer time (EDT)"); ax.plot(t.utc_hour, t.usWinter * 100, color=BLUE, label="US winter time (EST)")
ax.axhline(100 / 24, color=MUTED, lw=1, ls="-"); ax.text(0.2, 100 / 24 + 0.15, "flat = 4.2% per hour", ha="left", fontsize=8.5, color=MUTED)
ax.axvline(13.5, color=ORANGE, lw=0.9, alpha=.6); ax.axvline(14.5, color=BLUE, lw=0.9, alpha=.6)
ax.text(13.45, 8.7, "NY open\n13:30 UTC (summer)", ha="right", fontsize=8.5, color=INK2); ax.text(14.55, 8.7, "NY open\n14:30 UTC (winter)", ha="left", fontsize=8.5, color=INK2)
ax.set_xticks(range(0, 24)); ax.set_xlabel("UTC hour"); ax.set_ylabel("share of day's total variance (%)"); ax.set_ylim(0, 9.8)
ax.set_title("The busiest hours follow New-York time, not the UTC clock"); ax.legend(loc="upper left", fontsize=9)
note(fig, "Share of the sum of squared 5-minute returns falling in each UTC hour, 2021–2026. The 21:00 UTC hour is inflated by two single days (17 Aug 2023 ≈ 60% of that year's 21:00 variance; 10 Oct 2025 ≈ 54%).", y=-0.02)
save(fig, "F03_ny_open_dst")
# ---------- F14 yearly rates
fig, ax = plt.subplots(figsize=(9, 3.8)); W = 0.26
for k, (L, col, nm) in enumerate((("L1", AQUA, "≥1% in 2 h"), ("L2", BLUE, "≥2% in 8 h"), ("L3", VIOLET, "≥3% in 24 h"))):
    d = b[L]; vv = d != -9; r = pd.Series(((d != 0) & vv)[vv].astype(float)).groupby(year[vv]).mean()
    ax.bar(np.arange(6) + (k - 1) * W, r.values * 100, width=W - 0.03, color=col, label=nm)
    if L == "L2":
        for i, val in enumerate(r.values): ax.text(i, val * 100 + 1.5, f"{val*100:.0f}%", ha="center", fontsize=8.5, color=INK2)
ax.set_xticks(range(6)); ax.set_xticklabels(["2021", "2022", "2023", "2024", "2025", "2026*"]); ax.set_ylabel("share of hours that start such a move"); ax.legend(fontsize=9, loc="upper right")
ax.set_title("How often an hour starts a big move depends heavily on the year")
note(fig, "*2026 to Sep 22. A fixed 2% threshold means very different things in 2021 (annualised vol ≈ 96%) and 2023–2026 (≈ 45–54%).", y=-0.02)
save(fig, "F14_yearly_rates")
