# MOVE-ONSET ATLAS — frozen analysis plan (v1)
Written 2026-10-25 BEFORE any outcome was computed in this study. Locked by SHA-256 (file PLAN.sha256); every script refuses to run if this file's hash changed.

## 0. Status of this study (read first)
* EXPLORATORY / DESCRIPTIVE map of the whole BTCUSDT history. It is NOT a validation, NOT a hypothesis test under the project ledger, and does not change any ledger state.
* The ledger (PROJECT_STATE_v2 §7) lists "any new test on closed branches" and "new directional tests" as forbidden for the H-MOVE-04 path. The owner explicitly asked (2026-10-25 18:21) for a whole-data look at what precedes long/short moves, so this is run as a clearly separated descriptive study; nothing here may be quoted as evidence of an edge. Anything that looks interesting can only become a candidate through a NEW pre-registered protocol on FORWARD data (forward-journal spec r7).
* Data are burned (2021-01..2026-09 all previously looked at in other studies). Not blind. No clean holdout exists. Per-year / per-split consistency is reported only as a stability description.
* NOT done on purpose: open interest / liquidations / funding / basis (no point-in-time data on disk; OI is forbidden); combined multi-feature states or multi-feature models (ledger: forbidden); economic-calendar events (no data); Deribit/IV (no data); KCEX transferability (not audited).
* Venue: Binance USD-M BTCUSDT perpetual 5m OHLCV + taker_buy_base only. File pkg_data.csv sha256 0bea138cc96dfec0… (602,208 bars, 2021-01-01 00:00 → 2026-09-22 23:55 UTC, no missing/duplicate bars, no OHLC inconsistencies; 66 zero-volume bars; 3 bars with |open−prev close| ≥ 0.2%).

## 1. Time conventions
* Bar timestamp = bar OPEN (UTC). Bar i closes at ts_i+5min. Everything at decision time uses only bars ≤ i.
* Decision grid ("D-points"): every bar i with minute(ts_i)=55, i.e. decisions at each full UTC hour (N≈50k). Hour-of-day h = hour of the decision timestamp (= ts_i+5min). A decision at 13:00 uses data through 12:59:59.
* Splits by decision time: DISC < 2024-01-01; CONF 2024-01-01 … 2025-01-06; HOLD ≥ 2025-01-07. Years: 2021…2026 (2026 partial, ends 09-22).
* Weekly block id for clustering = year*100 + (dayofyear−1)//7.

## 2. Outcome labels (closes only; project definition style)
For D-point i and label set L=(θ,H): r_k = ln(C_{i+k}/C_i), k=1..H. First k with |r_k| ≥ ln(1+θ) (tolerance 1e-12) decides: dir=sign(r_k) (UP/DOWN), none → NONE. MOVE = UP or DOWN. Valid only if i+H ≤ N−1.
* L1 = (1%, 24 bars=2h) · L2 = (2%, 96 bars=8h; equals the ledger's MO-BIN-2%-8h target) · L3 = (3%, 288 bars=24h).
Outcome tests per cell (6): MOVE|L1, MOVE|L2, MOVE|L3 and UP-given-MOVE for L1, L2, L3.

## 3. Cell families (ALL declared; 164 cells × 6 outcomes = 984 tests; all are reported)
Continuous features are binned into 5 bins by DISC-period quantile edges (20/40/60/80 %), left-closed; edges frozen from DISC only. All features are causal at the decision bar.
**FAM-CAL (52 cells; tests vs year-adjusted overall base, no calendar adjustment for hour/dow cells)**
* C_H00..C_H23 hour-of-day (24); C_D0..C_D6 day-of-week Mon..Sun (7).
* Event-aligned hours (21, tested vs the hour×daytype baseline, REPORT-ONLY, no tier): for each event E in {Tokyo open 09:00 JST, London open 08:00 Europe/London, NY cash open 09:30 America/New_York, NY cash close 16:00 ET, CME Globex daily reopen 17:00 America/Chicago, Deribit Friday expiry 08:00 UTC, funding stamps 00/08/16 UTC} the D-points whose timestamp is −1h / 0h(first D-point at or after E) / +1h from E. (funding counts as one event with three stamps.)
* Hour-of-week 168-cell heatmap: display only, no inference.
**FAM-VOL (22)**: ln range12 (5), ln range288 (5), compression = ln range12 − ln range288 (5), varratio = ln[(Σr5² last 12 /12)/(Σr5² last 288 /288)] (5), NR24 (range12_t is the minimum of range12 at t, t−12 … t−276; 1 cell), WR24 (maximum; 1 cell). range_n = (max high − min low)/close over last n bars; r5 = 5m log return.
**FAM-LOC (41)**: pos24 (position of close inside the last-288-bar high-low range, 5 equal bins 0–.2–.4–.6–.8–1) (5); pos7d (2016 bars) (5); dayopen displacement z = ln(C/open of current UTC day)/(sqrt(Σ r5² over last 288 bars)) (5 quantile bins) (5); weekopen displacement analog vs Monday 00:00 UTC open (5); round-level proximity |C−5000·round(C/5000)|/C in {≤0.25%, (0.25%,1%], >1%} (3); BREAK_UP_N: C_t > max high of bars t−N..t−13 [excludes last hour], BREAK_DN_N: C_t < min low of that window, SWEEP_UP_N: max high over last 12 bars > that prior max high but C_t ≤ it, SWEEP_DN_N: min low over last 12 bars < prior min low but C_t ≥ it; N ∈ {48, 288, 2016, 8640} (16 cells); BOUNCE_UP: C_t ≥ 1.01×(min low of last 288 bars) and that low was set within the last 24 bars; BOUNCE_DN: C_t ≤ 0.99×(max high of last 288 bars) and that high set within last 24 bars (2 cells).
**FAM-CTX (20; momentum/reversal family is CLOSED in the ledger — control only)**: z_k = ln(C_t/C_{t−k})/(σ7d·√k) with σ7d = std of r5 over last 2016 bars; k ∈ {12, 48, 288, 2016} → 4×5 bins.
**FAM-FLOW (25; Volume-Delta/Taker-Imbalance family CLOSED — control only)**: VR = ln(V12_t / median of V12 at t−168h·j, j=1..8) (undefined before 2021-02-26) (5); TI_k = (2·Σtaker_buy − Σvolume)/Σvolume over last k bars, k ∈ {12, 48, 288} (15); ABS = VR − ln(range12_t / median range12 at same hour-of-week j=1..8) ("volume per unit range", 5). V12 = Σ volume of last 12 bars.
**FAM-FVG (4; SMC family CLOSED — control only)**: hourly candles (completed); bullish FVG at hour i: Low_i > High_{i−2} and (Low_i−High_{i−2})/Close_{i−1} ≥ 0.2%, zone=[High_{i−2},Low_i]; bearish mirror. FVG_FORM_BULL/BEAR: formed in the hour that just ended; FVG_RETEST_BULL/BEAR: during the hour that just ended price first traded into the zone of the latest still-unmitigated same-direction FVG formed within the last 48 h (unmitigated = no earlier trade through the zone; mitigated when close beyond far edge). (4 cells.)

## 4. Cell statistic (primary = within-year, calendar-adjusted)
* p_cal(h, daytype) from DISC D-points only, daytype ∈ {Mon–Fri, Sat–Sun}; 48 cells. e_i = p_cal(h_i,d_i)·s_{y(i)} where s_y = (observed events in year y)/(Σ p_cal over that year's valid D-points). (For FAM-CAL hour/dow cells use p = 1 instead of p_cal.)
* MOVE test: K=Σ_cell 1[MOVE], E=Σ_cell e_i; lift = K/E; effect size also reported as absolute pp difference (K/n − E/n). Cluster-robust (weekly blocks) SE of ln(lift): sqrt(W/(W−1)·Σ_w (K_w/K − E_w/E)²). Two-sided normal p. Cell testable only if K ≥ 30 and E ≥ 30.
* DIRECTION test (UP | MOVE): among MOVE D-points in the cell: d = (U − B)/N_ev, U=#UP, B=Σ b_{y(i)} with b_y = share of UP among MOVE in year y; cluster-robust SE as above. Testable only if N_ev ≥ 40. Also reported pooled (no year adjustment).
* Secondary view reported for every MOVE cell: pooled-calendar-adjusted lift (no year scaling), and per-year lifts (years with E_y ≥ 8).
* Single-feature information ranking (continuous features): AUC for MOVE|L2 within (year × hour-of-day) strata averaged by weight (calendar- and regime-adjusted), and AUC for UP vs DOWN among MOVE|L2 events within year strata.

## 5. Material effect and tiers (fixed now)
* Material: MOVE lift ≥ 1.25 or ≤ 0.80; direction |p_up − baseline| ≥ 0.03.
* TIER-A "clear": p ≤ 0.05/(tests in the cell's family) (Bonferroni per family, ledger style) AND also |z| ≥ placebo-calibrated 95th percentile of the family's max|z| (section 6) AND material AND sign agrees in all eligible years (≥5 eligible) except at most one, and in all of DISC/CONF/HOLD where eligible.
* TIER-B "hint": Benjamini-Hochberg q<0.05 over all 984 tests AND material AND sign agrees in ≥2/3 of eligible years.
* Everything else = "no distinguishable pattern". Tiers are descriptions of this sample, never evidence of an edge.

## 6. Placebo calibration (rule 10 of the ledger)
300 draws; outcome labels (all 6 outcome definitions together) circularly shifted relative to features by a random whole number of weeks k ∈ [8, 270] weeks (hour-of-week alignment preserved, long memory preserved); the full pipeline (p_cal, s_y, cell stats, z) is recomputed. For FAM-CAL hour/dow cells the shift is a random number of hours not divisible by 24. FAM-CAL event-aligned cells: no placebo (report-only). Per family: empirical distribution of max|z|, and the fraction of draws that would yield a Tier-A-style hit. Operative z-threshold per family = max(Bonferroni z, placebo 95th percentile of max|z|).

## 7. Descriptive modules (no tiers; every number reported)
* D1 Weekend "CME gap" PROXY: P_fri = close of the 5m bar ending Fri 16:00 America/Chicago; P_sun = open of the 5m bar starting Sun 17:00 America/Chicago; G=ln(P_sun/P_fri). Report distribution; fill rate (Binance trades back through P_fri) within 24h/72h/7d by |G| terciles; "toward-fill" share of the next-24h return sign; PLACEBO = same displacement construction at every other hourly time (reference lag = same hours as the weekend span of that week) conditioned on |G| tercile. Proxy only: real CME futures prices not on disk.
* D2 Timing: share of daily Σr5² by UTC hour (all years, per year, summer vs winter DST); hour-of-day distribution of the daily high/low (UTC day).
* D3 Concentration: share of total Σr5² from top 1/5/10 % of days and from top 20 days; list of top 30 days (range, return, weekday); top 20 5m bars by |return|.
* D4 Pivot anatomy: ZigZag on hourly closes with reversal 2% and 5%; pivot = extreme close; per pivot: leg size, duration, hour/dow, range12 DISC-percentile, pos24 at pivot, SWEEP flag (N=288), TI12; compared with all D-points of the same hour-of-day (random baseline); reversal-confirmation lag.
* D5 Real-time view of a trigger: for events BOUNCE_UP/DN, BREAK_UP/DN_288, SWEEP_UP/DN_288 and for all D-points (baseline): distribution of max favourable/adverse excursion of the next 8h and 24h, P(+2% before −1%) and P(−2% before +1%) from the decision close.
* D6 Event study: mean/median path of ln(C_{i+m}/C_i)/σ24 (σ24 = sqrt Σ r5² last 288) for m ∈ [−48h, +24h] for L2 UP / DOWN / NONE D-points, plus range12 percentile and VR path.
* D7 Gallery: 12 largest non-overlapping up and 12 largest down 24h impulses (ZigZag 2% legs, ranked by max excursion in the 24 h after the pivot); 5m candles −24h…+24h with onset marked; per-event feature readout.
* D8 Whole-history map: log price by year, with impulse onsets (L2 first D-point of each UP/DOWN cluster, ≥8h apart) marked; rolling event rate.

## 8. Reporting rules
Every cell and every test reported in CSV (no filtering). Headline figures in the report are taken from those CSVs. An independent re-implementation (separate agent, own code, from this plan only) re-computes the headline numbers before delivery. If the independent check disagrees, the report says so.
