import numpy as np, pandas as pd, warnings, time
import common, feat
warnings.filterwarnings("ignore")
common.check_plan()
df = common.load(); c = df.close.to_numpy(float); h = df.high.to_numpy(float); l = df.low.to_numpy(float); o = df.open.to_numpy(float)
v = df.volume.to_numpy(float); tb = df.taker_buy_base.to_numpy(float)
F = feat.compute(df); idx = F["idx"]; N = len(df)
ok_all = True
def report(name, ok, extra=""):
    global ok_all; ok_all &= bool(ok); print(("PASS " if ok else "FAIL ") + name, extra)

# T1 labels vs brute force on a random sample
lab = feat.labels(c, idx, common.LABELS)
rng = np.random.default_rng(7); samp = rng.choice(len(idx), 3000, replace=False)
bad = 0
for L, (th, H) in common.LABELS.items():
    for j in samp:
        i = idx[j]
        if i + H > N - 1: exp = -9
        else:
            exp = 0
            for k in range(1, H + 1):
                r = np.log(c[i + k] / c[i])
                if abs(r) >= np.log(1 + th) - 1e-12: exp = 1 if r > 0 else -1; break
        if lab[L][j] != exp: bad += 1
report("T1 labels == brute-force loop (3 sets x 3000 pts)", bad == 0, f"mismatches={bad}")

# T2 ledger anchor: per-year MOVE|L2 rate on D-points vs ledger (all-bar) rates 2021 .559, 2022 .346, 2023 .170
d = lab["L2"]; yrs = F["year"]
rates = {y: round(float((d[(yrs == y) & (d != -9)] != 0).mean()), 4) for y in range(2021, 2027)}
print("   L2 MOVE rate by year (hourly D-points):", rates, " ledger(all bars): 2021 .5594 2022 .3455 2023 .1695 conf(2024-01-01..2025-01-06) .2750")
report("T2 ledger anchor within 0.03", all(abs(rates[y] - t) < 0.03 for y, t in ((2021, .5594), (2022, .3455), (2023, .1695))))

# T3 causality: truncated-data recompute must reproduce earlier features exactly
keys = [k for k in F if k not in ("idx",)]
for T in (60000, 175008, 300000, 480000):
    T = (T // 12) * 12
    Ft = feat.compute(df.iloc[:T])
    nt = len(Ft["idx"]); worst = 0.0; badk = []
    for k in keys:
        a = np.asarray(F[k][:nt]); b = np.asarray(Ft[k])
        if a.dtype == bool:
            if not np.array_equal(a, b): badk.append(k)
        else:
            a = a.astype(float); b = b.astype(float)
            m = np.isfinite(a) | np.isfinite(b)
            if not np.array_equal(np.isfinite(a), np.isfinite(b)) or (m.any() and np.nanmax(np.abs(a[m] - b[m])) > 1e-9): badk.append(k)
    report(f"T3 causal: features at first {nt} D-points unchanged when future data removed (T={T})", not badk, str(badk[:8]))

# T4 independent re-derivations on a sample of D-points
def slow(i):
    out = {}
    w12 = slice(i - 11, i + 1); w288 = slice(i - 287, i + 1)
    out["ln_range12"] = np.log((h[w12].max() - l[w12].min()) / c[i]); out["ln_range288"] = np.log((h[w288].max() - l[w288].min()) / c[i])
    out["pos24"] = (c[i] - l[w288].min()) / (h[w288].max() - l[w288].min())
    out["TI12"] = (2 * tb[w12].sum() - v[w12].sum()) / v[w12].sum()
    r5 = np.diff(np.log(c[i - 2016:i + 1])); out["ctx48"] = np.log(c[i] / c[i - 48]) / (r5.std(ddof=1) * np.sqrt(48))
    out["BREAK_UP_288"] = c[i] > h[i - 288:i - 11].max()
    out["SWEEP_DN_48"] = (l[w12].min() < l[i - 48:i - 11].min()) and (c[i] >= l[i - 48:i - 11].min())
    out["BOUNCE_UP"] = (c[i] >= 1.01 * l[w288].min()) and (np.argmin(l[w288]) >= 288 - 24)
    out["BOUNCE_DN"] = (c[i] <= 0.99 * h[w288].max()) and (np.argmax(h[w288]) >= 288 - 24)
    s12 = (np.diff(np.log(c[i - 12:i + 1])) ** 2).sum(); s288 = (np.diff(np.log(c[i - 288:i + 1])) ** 2).sum()
    out["varratio"] = np.log((s12 / 12) / (s288 / 288))
    V12 = lambda t: v[t - 11:t + 1].sum(); R12 = lambda t: (h[t - 11:t + 1].max() - l[t - 11:t + 1].min()) / c[t]
    mv = np.median([V12(i - 2016 * j) for j in range(1, 9)]); mr = np.median([R12(i - 2016 * j) for j in range(1, 9)])
    out["VR"] = np.log(V12(i) / mv); out["ABS"] = out["VR"] - np.log(R12(i) / mr)
    r12s = [R12(i - 12 * k) for k in range(24)]; out["NR24"] = R12(i) <= min(r12s); out["WR24"] = R12(i) >= max(r12s)
    day0 = i - ((df.index[i].hour * 60 + df.index[i].minute) // 5); out["dayopen_z"] = np.log(c[i] / o[day0]) / np.sqrt(s288)
    return out
pos = rng.choice(np.where(idx > 20000)[0], 600, replace=False); bad = {}
for j in pos:
    s = slow(idx[j])
    for k, e in s.items():
        a = F[k][j]
        if isinstance(e, (bool, np.bool_)):
            if bool(a) != bool(e): bad[k] = bad.get(k, 0) + 1
        elif not (np.isfinite(a) and abs(a - e) < 1e-9 * max(1, abs(e))): bad[k] = bad.get(k, 0) + 1
report("T4 features == independent slow re-derivation (600 pts x 14 features)", not bad, str(bad))

# T5 FVG hand example
hc_h = np.array([10, 11, 13, 14, 12.5, 12.0, 11.0.__float__()]); hc_l = np.array([9, 10, 12, 13.2, 12.2, 10.5, 9.0])
hc_c = np.array([9.5, 10.5, 12.8, 13.8, 12.3, 11.0, 9.5]); hc_o = hc_c
fv = feat.fvg_cells(hc_o, hc_h, hc_l, hc_c, minsize=0.001)
# hour2: low 12 > high0 10 -> bullish FVG zone [10,12]; hour3: low13.2>high1 11 -> zone [11,13.2]; hour4 low 12.2 enters zone2(upper 13.2) (latest) -> retest; zone1 upper 12 not touched (12.2>12)
exp_form = [False, False, True, True, False, False, False]
report("T5a FVG formation flags", list(fv["FVG_FORM_BULL"]) == exp_form, str(list(fv["FVG_FORM_BULL"])))
report("T5b FVG retest: latest zone touched at hour 4, remaining zone at hour 5", list(fv["FVG_RETEST_BULL"]) == [False, False, False, False, True, True, False], str(list(fv["FVG_RETEST_BULL"])))

# T6 event-aligned cells: NY open shifts with DST (D0 at 14:00 UTC in summer, 15:00 UTC in winter)
dts = pd.DatetimeIndex(pd.to_datetime(F["dts_ns"], utc=True)); z0 = F["EV_NYOPEN_z0"]
hh = pd.Series(dts[z0].hour); mo = pd.Series(dts[z0].month)
summer = hh[(mo >= 4) & (mo <= 10)].value_counts().to_dict(); winter = hh[(mo == 12) | (mo <= 2)].value_counts().to_dict()
print("   NYOPEN_z0 hour counts summer(Apr-Oct):", summer, " winter(Dec-Feb):", winter)
report("T6 NY-open cell moves with DST", max(summer, key=summer.get) == 14 and max(winter, key=winter.get) == 15)
nd = len(df) / 288
print("   event cells hits:", {k: int(F[k].sum()) for k in F if k.startswith("EV_") and k.endswith("z0")}, "days", round(nd))
print("ALL PASS" if ok_all else "SOME FAILED")
