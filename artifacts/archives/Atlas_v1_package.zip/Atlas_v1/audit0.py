import numpy as np, pandas as pd, sys
df = pd.read_csv(sys.argv[1], parse_dates=["timestamp"]).set_index("timestamp")
print("rows", len(df), df.index[0], "->", df.index[-1])
print("monotonic", df.index.is_monotonic_increasing, "dups", int(df.index.duplicated().sum()))
full = pd.date_range(df.index[0], df.index[-1], freq="5min")
miss = full.difference(df.index)
print("expected", len(full), "missing bars", len(miss))
if len(miss):
    s = pd.Series(miss)
    grp = (s.diff() != pd.Timedelta("5min")).cumsum()
    runs = s.groupby(grp).agg(["first", "last", "count"])
    print("missing runs:", len(runs)); print(runs.sort_values("count", ascending=False).head(20).to_string())
for c in ["open","high","low","close","volume","taker_buy_base"]:
    print(c, "nan", int(df[c].isna().sum()), "min", df[c].min(), "max", df[c].max())
bad = ((df.high < df.low) | (df.high < df[["open","close"]].max(axis=1)) | (df.low > df[["open","close"]].min(axis=1))).sum()
print("OHLC inconsistent bars", int(bad))
print("taker_buy > volume", int((df.taker_buy_base > df.volume + 1e-9).sum()), " zero-volume bars", int((df.volume == 0).sum()))
# bar-to-bar gaps
g = np.log(df.open / df.close.shift(1)).where(df.index.to_series().diff() == pd.Timedelta("5min"))
print("open-vs-prev-close log gap: abs quantiles", g.abs().quantile([.5,.9,.99,.999,.9999]).round(6).to_dict(), "max", float(g.abs().max()))
print("bars with |gap|>=0.2%:", int((g.abs() >= 0.002).sum()), ">=0.5%:", int((g.abs() >= 0.005).sum()))
# 5m return outliers
r = np.log(df.close / df.close.shift(1))
print("5m |ret| max", float(r.abs().max()), "n>=2%", int((r.abs() >= 0.02).sum()), "n>=1%", int((r.abs() >= 0.01).sum()))
rg = np.log(df.high / df.low); print("5m range max", float(rg.max()), "n range>=3%", int((rg >= 0.03).sum()))
print("per-year bars:", df.groupby(df.index.year).size().to_dict())
print("per-year close first/last:", {y: (round(v.iloc[0],0), round(v.iloc[-1],0)) for y, v in df.close.groupby(df.index.year)})
