import numpy as np, pandas as pd, time, pickle
import common, stats_core as sc
common.check_plan()
A = sc.Atlas(); t0 = time.time()
out = A.run(); print("run", round(time.time() - t0, 2), "s")
rows = []
for name, r in out.items():
    for j, cell in enumerate(A.meta["cell"]):
        row = dict(outcome=name, cell=cell, family=A.meta.family[j], kind=A.meta.kind[j])
        for k in ("n", "K", "E", "lift", "pp", "rate", "se", "z", "p", "lift_pool", "lift_raw", "n_elig_y", "n_agree_y", "n_elig_s", "n_agree_s", "testable"):
            row[k] = r[k][j]
        for yi, y in enumerate(A.years): row[f"y{y}"] = r["ly"][yi, j]
        for si, s in enumerate(("DISC", "CONF", "HOLD")): row[f"s_{s}"] = r["ls"][si, j]
        rows.append(row)
res = pd.DataFrame(rows); res.to_csv("atlas_all_tests.csv", index=False)
pickle.dump(out, open("main_out.pkl", "wb"))
print(len(res), "tests;", int(res.testable.sum()), "testable")
print(res.groupby(["outcome"]).agg(testable=("testable", "sum")).T.to_string())
