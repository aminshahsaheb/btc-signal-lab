import numpy as np, pandas as pd, json, math
from scipy.stats import rankdata, norm
from numpy.lib.stride_tricks import sliding_window_view as swv

BASE = '/tmp/claude-0/-home-claude/cc374f45-f13d-557f-a909-7864793420a8/scratchpad/'
df = pd.read_csv(BASE + 'pkg_data.csv')
ts = pd.to_datetime(df['timestamp'], utc=True)
N = len(df)
O = df['open'].values.astype(float)
Hh = df['high'].values.astype(float)
Lw = df['low'].values.astype(float)
C = df['close'].values.astype(float)
V = df['volume'].values.astype(float)
TB = df['taker_buy_base'].values.astype(float)
lnC = np.log(C)
R = {}   # results

# ---- integrity
dts = np.diff(ts.values.astype('datetime64[s]').astype(np.int64))
assert (dts == 300).all(), 'gaps'
print('N', N, ts.iloc[0], ts.iloc[-1])

# ---- decision grid
minute = ts.dt.minute.values
idx = np.where(minute == 55)[0]
nD = len(idx)
dec_ts = ts.iloc[idx] + pd.Timedelta(minutes=5)
dec_ts = dec_ts.reset_index(drop=True)
dyear = dec_ts.dt.year.values
dhour = dec_ts.dt.hour.values
ddow = dec_ts.dt.dayofweek.values       # Mon=0
ddoy = dec_ts.dt.dayofyear.values
block = dyear * 100 + (ddoy - 1) // 7
daytype = (ddow >= 5).astype(int)
DISC = (dec_ts < pd.Timestamp('2024-01-01', tz='UTC')).values
import os
OUT = 'verify_results.json'
if os.environ.get('ALT_BAR_DATE'):
    bts = ts.iloc[idx].reset_index(drop=True)
    dyear = bts.dt.year.values; ddow = bts.dt.dayofweek.values; ddoy = bts.dt.dayofyear.values
    block = dyear * 100 + (ddoy - 1) // 7; daytype = (ddow >= 5).astype(int)
    DISC = (bts < pd.Timestamp('2024-01-01', tz='UTC')).values
    OUT = 'sens_barDate.json'
R['A_n_dpoints'] = int(nD)
print('nD', nD)

# ---- labels
def make_labels(theta, H):
    thr = math.log1p(theta) - 1e-12
    valid = (idx + H) <= (N - 1)
    d = np.zeros(nD, dtype=int)
    iv = np.where(valid)[0]
    W = swv(lnC, H + 1)[idx[iv]]
    r = W[:, 1:] - W[:, [0]]
    hit = np.abs(r) >= thr
    anyhit = hit.any(1)
    k = hit.argmax(1)
    sg = np.sign(r[np.arange(len(iv)), k]).astype(int)
    d[iv] = np.where(anyhit, sg, 0)
    # sensitivity: points within 1e-9 of threshold at some k
    near = (np.abs(np.abs(r) - math.log1p(theta)) < 1e-9).any(1).sum()
    return dict(valid=valid, dir=d, near=int(near))

LAB = {'L1': make_labels(0.01, 24), 'L2': make_labels(0.02, 96), 'L3': make_labels(0.03, 288)}
for L, lb in LAB.items():
    v = lb['valid']
    R['A_%s' % L] = dict(valid=int(v.sum()), UP=int(((lb['dir'] == 1) & v).sum()),
                         DOWN=int(((lb['dir'] == -1) & v).sum()), NONE=int(((lb['dir'] == 0) & v).sum()),
                         near_threshold_points=lb['near'])
    print(L, R['A_%s' % L])
v2 = LAB['L2']['valid']; m2 = (LAB['L2']['dir'] != 0)
R['A_L2_move_rate_by_year'] = {int(y): float(m2[v2 & (dyear == y)].mean()) for y in range(2021, 2027)}
R['A_L2_valid_by_year'] = {int(y): int((v2 & (dyear == y)).sum()) for y in range(2021, 2027)}
print(R['A_L2_move_rate_by_year'])

# ---- features at bar level (pandas rolling) then take at D-points
sH = pd.Series(Hh); sL = pd.Series(Lw); sC = pd.Series(C); sV = pd.Series(V); sTB = pd.Series(TB)
r5 = pd.Series(np.concatenate([[np.nan], np.diff(lnC)]))

def range_n(n):
    return ((sH.rolling(n).max() - sL.rolling(n).min()) / sC).values

rng12 = range_n(12)
rng288 = range_n(288)
print('zero ranges', (rng12[idx] == 0).sum(), (rng288[idx] == 0).sum())
F = {}
F['ln_range12'] = np.log(rng12[idx])
F['ln_range288'] = np.log(rng288[idx])
# NR24 (hourly arrays: D-points are every 12 bars)
rh = pd.Series(rng12[idx])
rmin24 = rh.rolling(24).min().values
F['NR24'] = (rng12[idx] <= rmin24)
F['NR24'] &= ~np.isnan(rmin24)
# VR (FAM-FLOW volume ratio)
V12 = sV.rolling(12).sum().values
stack = np.vstack([V12[idx - 2016 * j] if True else None for j in range(1, 9)]) if False else None
VRs = np.full((8, nD), np.nan)
for j in range(1, 9):
    ii = idx - 2016 * j
    ok = ii >= 0
    VRs[j - 1, ok] = V12[ii[ok]]
with np.errstate(all='ignore'):
    F['VR'] = np.log(V12[idx] / np.median(VRs, axis=0))
# varratio (FAM-VOL) alt
r2 = r5 ** 2
s12 = r2.rolling(12).sum().values
s288 = r2.rolling(288).sum().values
with np.errstate(all='ignore'):
    F['varratio'] = np.log((s12[idx] / 12) / (s288[idx] / 288))
# TI
def TI(k):
    a = sTB.rolling(k).sum().values; b = sV.rolling(k).sum().values
    return ((2 * a - b) / b)[idx]
F['TI48'] = TI(48)
F['TI288'] = TI(288)
# ctx
sig7 = r5.rolling(2016).std().values
def ctx(k):
    lag = np.full(N, np.nan); lag[k:] = lnC[:-k]
    return ((lnC - lag) / (sig7 * math.sqrt(k)))[idx]
F['ctx48'] = ctx(48)
F['ctx2016'] = ctx(2016)
# pos24
mx288 = sH.rolling(288).max().values; mn288 = sL.rolling(288).min().values
with np.errstate(all='ignore'):
    F['pos24'] = ((C - mn288) / (mx288 - mn288))[idx]
# break/sweep
def brk(Nn):
    w = Nn - 11
    pmax = sH.rolling(w).max().shift(12).values
    pmin = sL.rolling(w).min().shift(12).values
    mx12 = sH.rolling(12).max().values; mn12 = sL.rolling(12).min().values
    out = {}
    ok = ~np.isnan(pmax)
    out['BREAK_UP'] = ((C > pmax) & ok)[idx]
    out['BREAK_DN'] = ((C < pmin) & ok)[idx]
    out['SWEEP_UP'] = ((mx12 > pmax) & (C <= pmax) & ok)[idx]
    out['SWEEP_DN'] = ((mn12 < pmin) & (C >= pmin) & ok)[idx]
    return out
for Nn in (288, 2016, 8640):
    for k, v in brk(Nn).items():
        F['%s_%d' % (k, Nn)] = v
# FVG on hourly candles
hH = Hh.reshape(-1, 12).max(1); hL = Lw.reshape(-1, 12).min(1); hC = C.reshape(-1, 12)[:, -1]
assert len(hH) == nD
fb = np.zeros(nD, bool); fu = np.zeros(nD, bool)
fu[2:] = (hL[2:] > hH[:-2]) & ((hL[2:] - hH[:-2]) / hC[1:-1] >= 0.002)
fb[2:] = (hH[2:] < hL[:-2]) & ((hL[:-2] - hH[2:]) / hC[1:-1] >= 0.002)
F['FVG_FORM_BULL'] = fu; F['FVG_FORM_BEAR'] = fb
# calendar
F['C_H14'] = (dhour == 14)
F['C_D5'] = (ddow == 5)

# ---- bin edges from DISC
QS = [0.2, 0.4, 0.6, 0.8]
def edges(name):
    x = F[name]
    ok = DISC & np.isfinite(x)
    return np.quantile(x[ok], QS)
EDG = {}
for nme in ['ln_range12', 'ln_range288', 'VR', 'TI48', 'TI288', 'ctx48', 'ctx2016', 'varratio']:
    EDG[nme] = edges(nme)
    print(nme, EDG[nme], 'n_disc', int((DISC & np.isfinite(F[nme])).sum()))
R['D_edges'] = {k: [float(a) for a in v] for k, v in EDG.items()}

def binof(name):
    x = F[name]
    b = np.searchsorted(EDG[name], x, side='right').astype(float)
    b[np.isnan(x)] = np.nan
    return b
BIN = {k: binof(k) for k in EDG}
pb = np.floor(F['pos24'] * 5); pb = np.minimum(pb, 4); BIN['pos24'] = pb   # NaN stays NaN

# ---- statistics
def clustered_se(num_a, den_a, num_b, den_b, blk, allblocks=None):
    """SE of ln(num_a/den_a): sqrt(W/(W-1) sum_w (a_w/A - b_w/B)^2)  (A=sum a, B=sum b)"""
    ub, inv = np.unique(blk, return_inverse=True)
    aw = np.bincount(inv, weights=num_a, minlength=len(ub))
    bw = np.bincount(inv, weights=num_b, minlength=len(ub))
    Wn = len(ub)
    A = num_a.sum(); B = num_b.sum()
    s = ((aw / A - bw / B) ** 2).sum()
    se = math.sqrt(Wn / (Wn - 1) * s)
    return se, Wn

def move_test(cell, L, flat=False):
    lb = LAB[L]; valid = lb['valid']; move = (lb['dir'] != 0).astype(float)
    # baseline
    if flat:
        pc = np.ones(nD)
    else:
        tab = np.zeros((24, 2))
        for h in range(24):
            for dt in range(2):
                m = DISC & valid & (dhour == h) & (daytype == dt)
                tab[h, dt] = move[m].mean()
        pc = tab[dhour, daytype]
    s_y = {}
    for y in range(2021, 2027):
        m = valid & (dyear == y)
        s_y[y] = move[m].sum() / pc[m].sum()
    sy = np.array([s_y.get(y, np.nan) for y in dyear])
    e = pc * sy
    c = cell & valid
    K = move[c].sum(); E = e[c].sum(); n = int(c.sum())
    lift = K / E
    se, Wn = clustered_se(move[c], None, e[c], None, block[c])
    # alt: W = all blocks with valid pts
    Wall = len(np.unique(block[valid]))
    se_alt = math.sqrt(Wall / (Wall - 1) * (se ** 2 * (Wn - 1) / Wn))
    z = math.log(lift) / se
    return dict(n=n, K=float(K), E=float(E), lift=float(lift), se_ln_lift=float(se), z=float(z),
                p=float(2 * norm.sf(abs(z))), W_blocks=int(Wn), z_altW=float(math.log(lift) / se_alt),
                abs_pp=float(100 * (K - E) / n), testable=bool(K >= 30 and E >= 30))

def dir_test(cell, L):
    lb = LAB[L]; valid = lb['valid']; d = lb['dir']
    mv = valid & (d != 0)
    up = (d == 1).astype(float)
    b_y = {}
    for y in range(2021, 2027):
        m = mv & (dyear == y)
        b_y[y] = up[m].mean()
    by = np.array([b_y.get(y, np.nan) for y in dyear])
    c = cell & mv
    Nev = int(c.sum()); U = float(up[c].sum()); B = float(by[c].sum())
    dd = (U - B) / Nev
    g = (up[c] - by[c])   # per-event residual
    ub, inv = np.unique(block[c], return_inverse=True)
    Wn = len(ub)
    Sw = np.bincount(inv, weights=g, minlength=Wn)
    nw = np.bincount(inv, minlength=Wn).astype(float)
    # centred (ratio linearisation)
    se_c = math.sqrt(Wn / (Wn - 1) * ((Sw - dd * nw) ** 2).sum()) / Nev
    # uncentred
    se_u = math.sqrt(Wn / (Wn - 1) * (Sw ** 2).sum()) / Nev
    # lift-style analog: ln(U/B)
    uw = np.bincount(inv, weights=up[c], minlength=Wn); bw = np.bincount(inv, weights=by[c], minlength=Wn)
    se_ln = math.sqrt(Wn / (Wn - 1) * ((uw / U - bw / B) ** 2).sum())
    return dict(N_ev=Nev, U=U, B=B, d=float(dd), se=float(se_c), z=float(dd / se_c),
                se_uncentered=float(se_u), z_uncentered=float(dd / se_u),
                se_via_lnUB_times_B_over_Nev=float(se_ln * B / Nev), z_lnUB=float(math.log(U / B) / se_ln),
                W_blocks=int(Wn), p_up_cell=float(U / Nev), p_up_base=float(B / Nev),
                testable=bool(Nev >= 40))

def fin(name):
    return np.isfinite(F[name])

R['B_move'] = {}
def put(key, res):
    R['B_move'][key] = res
    print(key, {k: (round(v, 5) if isinstance(v, float) else v) for k, v in res.items()})

top = lambda nme: (BIN[nme] == 4)
low = lambda nme: (BIN[nme] == 0)
put('ln_range12_b4_L1', move_test(top('ln_range12'), 'L1'))
put('ln_range12_b4_L2', move_test(top('ln_range12'), 'L2'))
put('ln_range288_b0_L2', move_test(low('ln_range288'), 'L2'))
put('VR_b4_L2', move_test(top('VR'), 'L2'))
put('varratio_b4_L2_ALT', move_test(top('varratio'), 'L2'))
put('BREAK_DN_2016_L1', move_test(F['BREAK_DN_2016'], 'L1'))
put('SWEEP_DN_8640_L3', move_test(F['SWEEP_DN_8640'], 'L3'))
put('NR24_L1', move_test(F['NR24'], 'L1'))
put('FVG_FORM_BEAR_L1', move_test(F['FVG_FORM_BEAR'], 'L1'))
put('C_H14_L1_flat', move_test(F['C_H14'], 'L1', flat=True))
put('C_D5_L3_flat', move_test(F['C_D5'], 'L3', flat=True))
put('ctx2016_b0_L2', move_test(low('ctx2016'), 'L2'))

R['C_dir'] = {}
def putd(key, res):
    R['C_dir'][key] = res
    print(key, {k: (round(v, 5) if isinstance(v, float) else v) for k, v in res.items()})
putd('pos24_b4_L1', dir_test(top('pos24'), 'L1'))
putd('TI48_b4_L1', dir_test(top('TI48'), 'L1'))
putd('ctx48_b0_L1', dir_test(low('ctx48'), 'L1'))
putd('BREAK_UP_288_L1', dir_test(F['BREAK_UP_288'], 'L1'))
putd('TI288_b4_L2', dir_test(top('TI288'), 'L2'))
putd('FVG_FORM_BEAR_L1', dir_test(F['FVG_FORM_BEAR'], 'L1'))

# ---- E: AUC
def auc_stat(x, y):
    """P(x_pos > x_neg)+0.5 ties; y bool"""
    rk = rankdata(x)
    npos = y.sum(); nneg = len(y) - npos
    return (rk[y].sum() - npos * (npos + 1) / 2) / (npos * nneg), npos, nneg

def weighted_auc(feature, pos_mask, pop_mask, strata_keys):
    ok = pop_mask & ~np.isnan(feature)
    d = pd.DataFrame({'x': feature[ok], 'y': pos_mask[ok], 'k': pd.Series(strata_keys).values[ok] if False else strata_keys[ok]})
    num = 0.0; den = 0.0; used = 0; skipped = 0
    for k, g in d.groupby('k'):
        y = g['y'].values.astype(bool)
        npos = y.sum(); nneg = len(y) - npos
        if npos < 10 or nneg < 10:
            skipped += 1; continue
        a, _, _ = auc_stat(g['x'].values, y)
        w = npos * nneg
        num += a * w; den += w; used += 1
    return dict(auc=float(num / den), strata_used=used, strata_skipped=skipped, weight_total=float(den))

v2 = LAB['L2']['valid']; mv2 = (LAB['L2']['dir'] != 0)
strat_yh = dyear * 100 + dhour
R['E_auc'] = {}
for nme in ['ln_range12', 'VR', 'varratio']:
    R['E_auc']['%s_MOVE_L2_yearXhour' % nme] = weighted_auc(F[nme], mv2, v2, strat_yh)
mvpop = v2 & mv2
R['E_auc']['TI288_UPvsDOWN_L2_year'] = weighted_auc(F['TI288'], (LAB['L2']['dir'] == 1), mvpop, dyear)
print(R['E_auc'])

# ---- F: D1 weekend gap
loc = ts.dt.tz_convert('America/Chicago')
ldow = loc.dt.dayofweek.values; lh = loc.dt.hour.values; lm = loc.dt.minute.values
ldate = loc.dt.tz_localize(None).dt.normalize().values
fri_bars = np.where((ldow == 4) & (lh == 15) & (lm == 55))[0]
sun_bars = np.where((ldow == 6) & (lh == 17) & (lm == 0))[0]
sun_by_date = {ldate[i]: i for i in sun_bars}
pairs = []
for f in fri_bars:
    sd = ldate[f] + np.timedelta64(2, 'D')
    if sd in sun_by_date:
        pairs.append((f, sun_by_date[sd]))
print('weekends', len(pairs), 'fri bars', len(fri_bars), 'sun bars', len(sun_bars))
Pf = np.array([C[f] for f, s in pairs]); Ps = np.array([O[s] for f, s in pairs])
G = np.log(Ps / Pf)
d1 = {'n_weekends': len(pairs), 'median_abs_G_pct': float(100 * np.median(np.abs(G))),
      'n_G_zero': int((G == 0).sum()), 'n_gap_up': int((G > 0).sum()), 'n_gap_dn': int((G < 0).sum()),
      'first_weekend_fri_bar': str(ts.iloc[pairs[0][0]]), 'last_weekend_sun_bar': str(ts.iloc[pairs[-1][1]])}
span_h = [(ts.iloc[s] - ts.iloc[f]).total_seconds() / 3600 for f, s in pairs]
d1['span_hours_set'] = sorted(set(round(x, 3) for x in span_h))
for lab, nb in (('24h', 288), ('72h', 864), ('7d', 2016)):
    flags = []; fl_all = []
    for (f, s), p, g in zip(pairs, Pf, G):
        e = s + nb          # bars with open in [s, s+nb)  i.e. [reopen, reopen+window)
        full = e <= N
        filled = bool((Lw[s:e] <= p).any()) if g > 0 else bool((Hh[s:e] >= p).any())
        fl_all.append(filled)
        if full: flags.append(filled)
    d1['fill_share_%s' % lab] = float(np.mean(fl_all))               # denominator = all weekends
    d1['fill_k_%s' % lab] = int(np.sum(fl_all))
    d1['fill_share_%s_completeWindowsOnly_ALT' % lab] = float(np.mean(flags)); d1['fill_n_complete_%s' % lab] = len(flags)
    fl2 = []
    for (f, s), p, g in zip(pairs, Pf, G):
        e = s + nb + 1
        if e > N: continue
        fl2.append(bool((Lw[s:e] <= p).any()) if g > 0 else bool((Hh[s:e] >= p).any()))
    d1['fill_share_%s_inclusiveEndBar_ALT' % lab] = float(np.mean(fl2))
R['F_D1'] = d1
print(d1)

# ---- G: zigzag
def zigzag(c, th, mode):
    up_m = 1 + th
    dn_m = (1 - th) if mode == 'pct' else 1 / (1 + th)
    n = len(c)
    hi = lo = c[0]; hi_i = lo_i = 0; state = 0
    piv = []
    for k in range(1, n):
        x = c[k]
        if state == 0:
            if x > hi: hi, hi_i = x, k
            if x < lo: lo, lo_i = x, k
            if x >= lo * up_m:
                piv.append((lo_i, 'L', k)); state = 1; hi, hi_i = x, k
            elif x <= hi * dn_m:
                piv.append((hi_i, 'H', k)); state = -1; lo, lo_i = x, k
        elif state == 1:
            if x > hi: hi, hi_i = x, k
            elif x <= hi * dn_m:
                piv.append((hi_i, 'H', k)); state = -1; lo, lo_i = x, k
        else:
            if x < lo: lo, lo_i = x, k
            elif x >= lo * up_m:
                piv.append((lo_i, 'L', k)); state = 1; hi, hi_i = x, k
    return piv
Ch = C[idx]
R['G_D4'] = {}
for mode in ('pct', 'log'):
    for th in (0.02, 0.05):
        piv = zigzag(Ch, th, mode)
        lag = np.array([c - p for p, t, c in piv], float)
        lows = [x for x in piv if x[1] == 'L']; highs = [x for x in piv if x[1] == 'H']
        key = 'th%g_%s%s' % (th, mode, '' if mode == 'pct' else '_ALT')
        R['G_D4'][key] = dict(n_pivots=len(piv), n_low=len(lows), n_high=len(highs),
                              median_lag_h=float(np.median(lag)),
                              median_lag_low=float(np.median([c - p for p, t, c in lows])),
                              median_lag_high=float(np.median([c - p for p, t, c in highs])),
                              mean_lag_h=float(lag.mean()))
        print(key, R['G_D4'][key])

# ---- H: D3 concentration
day = ts.dt.floor('D').values
cnt = pd.Series(day).value_counts()
full_days = set(cnt[cnt == 288].index)
r5v = r5.values
df2 = pd.DataFrame({'day': day, 'r2': r5v ** 2})
dsum = df2.groupby('day')['r2'].sum(min_count=1)   # NaN skipped
dsum = dsum[dsum.index.isin(full_days)]
nd = len(dsum)
tot = dsum.sum()
srt = np.sort(dsum.values)[::-1]
h = {'ndays': int(nd), 'n_days_total_in_data': int(len(cnt))}
for p in (0.01, 0.05, 0.10):
    k = int(round(p * nd))
    h['top%d%%' % round(p * 100)] = dict(k=k, share=float(srt[:k].sum() / tot))
R['H_D3'] = h
print(h)

# ---- diagnostics
R['diag'] = dict(
    n_valid_feat={k: int(np.isfinite(F[k]).sum()) for k in ['ln_range12', 'ln_range288', 'VR', 'varratio', 'TI48', 'TI288', 'ctx48', 'ctx2016', 'pos24']},
    n_events={k: int(F[k].sum()) for k in F if F[k].dtype == bool},
    n_disc=int(DISC.sum()),
    bin_counts_b4_ln_range12=int(top('ln_range12').sum()),
)
with open(BASE + 'verify/' + OUT, 'w') as f:
    json.dump(R, f, indent=1)
print('done')
