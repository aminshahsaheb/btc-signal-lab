import numpy as np, pandas as pd
from numpy.lib.stride_tricks import sliding_window_view as swv

P = '/tmp/claude-0/-home-claude/cc374f45-f13d-557f-a909-7864793420a8/scratchpad/pkg_data.csv'
df = pd.read_csv(P)
ts = pd.to_datetime(df['timestamp'], utc=True)
o = df['open'].values.astype(float); h = df['high'].values.astype(float)
l = df['low'].values.astype(float); c = df['close'].values.astype(float)
v = df['volume'].values.astype(float); tb = df['taker_buy_base'].values.astype(float)
N = len(df)
assert (np.diff(ts.values.astype('datetime64[s]').astype(np.int64)) == 300).all()

r5 = np.full(N, np.nan); r5[1:] = np.diff(np.log(c))
r5sq = r5 ** 2

def wsum(x, n):
    """sum of x[t-n+1..t]; NaN if any NaN or t<n-1 (exact, via sliding windows)"""
    out = np.full(len(x), np.nan)
    out[n - 1:] = swv(x, n).sum(axis=1)
    return out

def rmax(x, n):
    return pd.Series(x).rolling(n, min_periods=n).max().values

def rmin(x, n):
    return pd.Series(x).rolling(n, min_periods=n).min().values

# decision grid
minute = ts.dt.minute.values
D = np.where(minute == 55)[0]
dts = ts.iloc[D] + pd.Timedelta(minutes=5)
dts = pd.DatetimeIndex(dts.values).tz_localize('UTC') if dts.dt.tz is None else pd.DatetimeIndex(dts)
hour = dts.hour.values
dow = dts.dayofweek.values          # Mon=0
year = dts.year.values
doy = dts.dayofyear.values
block = year * 100 + (doy - 1) // 7
daytype = (dow >= 5).astype(int)
split = np.where(dts < pd.Timestamp('2024-01-01', tz='UTC'), 0,
         np.where(dts < pd.Timestamp('2025-01-07', tz='UTC'), 1, 2))
ND = len(D)

# labels
LS = {'L1': (0.01, 24), 'L2': (0.02, 96), 'L3': (0.03, 288)}
def labels(theta, H):
    thr = np.log1p(theta) - 1e-12
    valid = (D + H) <= (N - 1)
    lab = np.zeros(ND, dtype=int)   # +1 UP, -1 DOWN, 0 NONE
    Dv = D[valid]
    lc = np.log(c)
    out = np.zeros(len(Dv), dtype=int)
    CH = 4000
    for a in range(0, len(Dv), CH):
        idx = Dv[a:a + CH]
        M = lc[idx[:, None] + np.arange(1, H + 1)[None, :]] - lc[idx][:, None]
        hit = np.abs(M) >= thr
        anyhit = hit.any(axis=1)
        first = hit.argmax(axis=1)
        s = np.sign(M[np.arange(len(idx)), first]).astype(int)
        out[a:a + CH] = np.where(anyhit, s, 0)
    lab[valid] = out
    return lab, valid

LAB = {}; VAL = {}
for k, (th, H) in LS.items():
    LAB[k], VAL[k] = labels(th, H)
