from common import *

with np.errstate(all='ignore'):
    # --- range features
    rng12 = (rmax(h, 12) - rmin(l, 12)) / c
    rng288 = (rmax(h, 288) - rmin(l, 288)) / c
    def safe_ln(x):
        x = np.asarray(x, float)
        out = np.full(x.shape, np.nan)
        m = np.isfinite(x) & (x > 0)
        out[m] = np.log(x[m])
        return out
    ln12 = safe_ln(rng12); ln288 = safe_ln(rng288)
    comp = ln12 - ln288
    s12 = wsum(r5sq, 12); s288 = wsum(r5sq, 288)
    varratio = safe_ln((s12 / 12) / (s288 / 288))
    # NR24 / WR24 : range12 at t, t-12, ..., t-276
    R = np.full((24, N), np.nan)
    for j in range(24):
        R[j, 12 * j:] = rng12[:N - 12 * j]
    nr24 = (rng12 <= np.nanmin(R, axis=0)) & ~np.isnan(R).any(axis=0)
    wr24 = (rng12 >= np.nanmax(R, axis=0)) & ~np.isnan(R).any(axis=0)
    nr24_valid = ~np.isnan(R).any(axis=0) & np.isfinite(rng12)

    # --- location
    mx288 = rmax(h, 288); mn288 = rmin(l, 288)
    pos24 = (c - mn288) / (mx288 - mn288)
    pos24[~np.isfinite(pos24)] = np.nan

    # break / sweep, prior window = bars t-N .. t-12 (E1)
    BS = {}
    mx12 = rmax(h, 12); mn12 = rmin(l, 12)
    for Nn in (48, 288, 2016, 8640):
        pm = rmax(h, Nn - 11)    # window of Nn-11 bars ending at bar t-12 ... shift by 12
        pn = rmin(l, Nn - 11)
        pmax = np.full(N, np.nan); pmin = np.full(N, np.nan)
        pmax[12:] = pm[:N - 12]; pmin[12:] = pn[:N - 12]   # window ending t-12, length Nn-11 => starts t-Nn
        ok = np.isfinite(pmax)
        BS[f'BREAK_UP_{Nn}'] = (np.where(ok, c > pmax, False), ok)
        BS[f'BREAK_DN_{Nn}'] = (np.where(ok, c < pmin, False), ok)
        BS[f'SWEEP_UP_{Nn}'] = (np.where(ok, (mx12 > pmax) & (c <= pmax), False), ok)
        BS[f'SWEEP_DN_{Nn}'] = (np.where(ok, (mn12 < pmin) & (c >= pmin), False), ok)

    # --- ctx
    sig7 = pd.Series(r5).rolling(2016).std(ddof=1).values
    ctx = {}
    for k in (12, 48, 288, 2016):
        lr = np.full(N, np.nan); lr[k:] = np.log(c[k:] / c[:N - k])
        ctx[k] = lr / (sig7 * np.sqrt(k))

    # --- flow
    V12 = wsum(v, 12)
    med = np.full(N, np.nan)
    st = np.full((8, N), np.nan)
    for j in range(1, 9):
        st[j - 1, 2016 * j:] = V12[:N - 2016 * j]
    med = np.median(st, axis=0)     # NaN if any NaN
    VRf = safe_ln(V12 / med)
    TI = {}
    for k in (12, 48, 288):
        TI[k] = (2 * wsum(tb, k) - wsum(v, k)) / wsum(v, k)
        TI[k][~np.isfinite(TI[k])] = np.nan

# FVG hourly
nh = N // 12
assert nh * 12 == N and D[0] == 11 and (D == 12 * np.arange(nh) + 11).all()
Hh = h.reshape(nh, 12).max(axis=1); Lh = l.reshape(nh, 12).min(axis=1)
Ch = c.reshape(nh, 12)[:, -1]
fvg_bear = np.zeros(nh, bool); fvg_bull = np.zeros(nh, bool); fvg_ok = np.zeros(nh, bool)
fvg_ok[2:] = True
fvg_bear[2:] = (Hh[2:] < Lh[:-2]) & ((Lh[:-2] - Hh[2:]) / Ch[1:-1] >= 0.002)
fvg_bull[2:] = (Lh[2:] > Hh[:-2]) & ((Lh[2:] - Hh[:-2]) / Ch[1:-1] >= 0.002)

# features at D
def atD(x): return np.asarray(x)[D]
F = {
 'ln_range12': atD(ln12), 'ln_range288': atD(ln288), 'compression': atD(comp), 'varratio': atD(varratio),
 'pos24': atD(pos24), 'VR': atD(VRf),
 'TI12': atD(TI[12]), 'TI48': atD(TI[48]), 'TI288': atD(TI[288]),
 'ctx12': atD(ctx[12]), 'ctx48': atD(ctx[48]), 'ctx288': atD(ctx[288]), 'ctx2016': atD(ctx[2016]),
}
BIN_EDGES_Q = {}
def disc_edges(x):
    m = (split == 0) & np.isfinite(x)
    return np.quantile(x[m], [0.2, 0.4, 0.6, 0.8])
def binof(x, edges):
    b = np.searchsorted(edges, x, side='right').astype(float)
    b[~np.isfinite(x)] = np.nan
    return b
QF = ['ln_range12', 'ln_range288', 'compression', 'varratio', 'VR', 'TI12', 'TI48', 'TI288', 'ctx12', 'ctx48', 'ctx288', 'ctx2016']
EDGES = {}; BINS = {}
for f in QF:
    EDGES[f] = disc_edges(F[f]); BINS[f] = binof(F[f], EDGES[f])
pe = np.array([0.2, 0.4, 0.6, 0.8])
BINS['pos24'] = binof(F['pos24'], pe)

# binary cells: (event array at D, valid array at D)
BIN = {}
for kname, (ev, ok) in BS.items():
    BIN[kname] = (atD(ev).astype(bool), atD(ok))
BIN['NR24'] = (atD(nr24), atD(nr24_valid))
BIN['WR24'] = (atD(wr24), atD(nr24_valid))
BIN['FVG_FORM_BEAR'] = (fvg_bear, fvg_ok)
BIN['FVG_FORM_BULL'] = (fvg_bull, fvg_ok)
