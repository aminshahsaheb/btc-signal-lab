from features import *
from scipy import stats as st_

def move_arr(Lk):
    return (LAB[Lk] != 0).astype(float)

def base_terms(Lk, flat=False):
    """per-D-point expected-prob e_i (NaN for invalid labels)."""
    valid = VAL[Lk]; mv = move_arr(Lk)
    e = np.full(ND, np.nan)
    if flat:
        p = np.ones(ND)
    else:
        p = np.full(ND, np.nan)
        for hh in range(24):
            for dt in (0, 1):
                m = (split == 0) & valid & (hour == hh) & (daytype == dt)
                p[(hour == hh) & (daytype == dt)] = mv[m].mean()
    for y in np.unique(year):
        m = valid & (year == y)
        s = mv[m].sum() / p[m].sum()
        e[m] = p[m] * s
    return e

def cl_se_lift(K_w, E_w, Wcount):
    K = K_w.sum(); E = E_w.sum()
    return np.sqrt(Wcount / (Wcount - 1) * np.sum((K_w / K - E_w / E) ** 2))

def move_test(Lk, cellmask, flat=False):
    valid = VAL[Lk]; mv = move_arr(Lk)
    e = base_terms(Lk, flat)
    m = cellmask & valid
    n = int(m.sum()); K = mv[m].sum(); E = e[m].sum()
    lift = K / E
    blocks = block[m]
    ub, inv = np.unique(blocks, return_inverse=True)
    K_w = np.bincount(inv, weights=mv[m]); E_w = np.bincount(inv, weights=e[m])
    W = len(ub)
    se = cl_se_lift(K_w, E_w, W)
    Wall = len(np.unique(block[valid]))
    # alt: all weekly blocks in sample (zeros for blocks without cell members)
    se_all = np.sqrt(Wall / (Wall - 1) * np.sum((K_w / K - E_w / E) ** 2))
    z = np.log(lift) / se
    return dict(n=n, K=float(K), E=float(E), lift=float(lift), se_lnlift=float(se), z=float(z),
                p=float(2 * (1 - st_.norm.cdf(abs(z)))), W_cell=int(W), W_all=int(Wall),
                se_alt_Wall=float(se_all), z_alt_Wall=float(np.log(lift) / se_all),
                pp_diff=float((K - E) / n))

def dir_test(Lk, cellmask):
    valid = VAL[Lk]; lab = LAB[Lk]
    mvm = valid & (lab != 0)
    up = (lab == 1).astype(float)
    b = np.full(ND, np.nan)
    for y in np.unique(year):
        m = mvm & (year == y)
        b[year == y] = up[m].mean()
    m = cellmask & mvm
    Nev = int(m.sum()); U = up[m].sum(); B = b[m].sum()
    d = (U - B) / Nev
    ub, inv = np.unique(block[m], return_inverse=True)
    Uw = np.bincount(inv, weights=up[m]); Bw = np.bincount(inv, weights=b[m]); Nw = np.bincount(inv).astype(float)
    W = len(ub)
    cen = (Uw - Bw - d * Nw) / Nev
    unc = (Uw - Bw) / Nev
    se_c = np.sqrt(W / (W - 1) * np.sum(cen ** 2))
    se_u = np.sqrt(W / (W - 1) * np.sum(unc ** 2))
    Wall = len(np.unique(block[mvm]))
    se_c_all = np.sqrt(Wall / (Wall - 1) * np.sum(cen ** 2))
    se_u_all = np.sqrt(Wall / (Wall - 1) * np.sum(unc ** 2))
    return dict(N_ev=Nev, U=float(U), B=float(B), d=float(d), se=float(se_c), z=float(d / se_c),
                se_uncentered=float(se_u), z_uncentered=float(d / se_u),
                se_centered_Wall=float(se_c_all), z_centered_Wall=float(d / se_c_all),
                se_uncentered_Wall=float(se_u_all), z_uncentered_Wall=float(d / se_u_all),
                W_cell=int(W), W_all=int(Wall), p_up=float(U / Nev), p_base=float(B / Nev))

def auc_strata(feat, pos, neg_mask_valid, strata_keys):
    """feat: array; pos: bool array for positives; neg_mask_valid: bool mask of eligible points (pos or neg).
    strata_keys: list of arrays. returns weighted mean AUC."""
    okm = neg_mask_valid & np.isfinite(feat)
    key = np.zeros(ND, dtype=np.int64)
    for kk in strata_keys:
        key = key * 1000 + kk.astype(np.int64)
    num = 0.0; den = 0.0; used = 0; skipped = 0
    for kv in np.unique(key[okm]):
        mm = okm & (key == kv)
        x = feat[mm]; y = pos[mm]
        npos = int(y.sum()); nneg = int((~y).sum())
        if npos < 10 or nneg < 10:
            skipped += 1; continue
        rk = st_.rankdata(x)
        auc = (rk[y].sum() - npos * (npos + 1) / 2) / (npos * nneg)
        w = npos * nneg
        num += w * auc; den += w; used += 1
    return num / den, used, skipped
