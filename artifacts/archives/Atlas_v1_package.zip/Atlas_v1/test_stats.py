import numpy as np, pandas as pd, scipy.sparse as sp
import common, stats_core as sc
common.check_plan()
A = sc.Atlas(); out = A.run()
M = A.M.tocsr(); rng = np.random.default_rng(3)
cells = list(rng.choice(A.C, 10, replace=False)) + [list(A.meta.cell).index(x) for x in ("C_H14", "ln_range288_b0", "BREAK_UP_288")]
ok = True
for L in ("L1", "L2", "L3"):
    d = A.labs[L].astype(int); valid = d != -9
    df = pd.DataFrame(dict(h=A.hour, dt=(A.dow >= 5).astype(int), yr=A.year, blk=A.block, d=d, valid=valid, split=A.split))
    v = df[df.valid]
    disc = v[v.split == 0]
    pc = disc.groupby(["h", "dt"]).apply(lambda g: (g.d != 0).mean()).to_dict()
    v = v.assign(y=(v.d != 0).astype(float), pcal=[pc[(h, t)] for h, t in zip(v.h, v.dt)])
    sy = v.groupby("yr").apply(lambda g: g.y.sum() / g.pcal.sum()); ry = v.groupby("yr").y.mean()
    v = v.assign(e_cal=v.pcal * v.yr.map(sy), e_flat=v.yr.map(ry))
    shy = v[v.d != 0].groupby("yr").apply(lambda g: (g.d == 1).mean()); 
    for j in cells:
        mem = np.asarray(M[:, j].todense()).ravel() > 0
        vm = v[mem[v.index]]
        e = vm.e_flat if A.flat[j] else vm.e_cal
        K = vm.y.sum(); E = e.sum(); lift = K / E
        g = pd.DataFrame(dict(blk=vm.blk, y=vm.y, e=e)).groupby("blk").sum()
        allb = pd.Series(0.0, index=np.unique(A.block)); Kb = allb.add(g.y, fill_value=0); Eb = allb.add(g.e, fill_value=0)
        W = len(allb); se = np.sqrt(W / (W - 1) * (((Kb / K - Eb / E) ** 2).sum())); z = np.log(lift) / se
        r = out[f"MOVE_{L}"]
        if not (np.isclose(r["K"][j], K) and np.isclose(r["E"][j], E, rtol=1e-9) and np.isclose(r["se"][j], se, rtol=1e-9) and (np.isclose(r["z"][j], z, rtol=1e-9) or np.isnan(r["z"][j]))):
            ok = False; print("MOVE mismatch", L, A.meta.cell[j], r["K"][j], K, r["E"][j], E, r["se"][j], se)
        # direction
        ev = vm[vm.d != 0]; U = (ev.d == 1).sum(); Nev = len(ev); B = ev.yr.map(shy).sum()
        dd = (U - B) / Nev
        gg = pd.DataFrame(dict(blk=ev.blk, u=(ev.d == 1).astype(float), b=ev.yr.map(shy), n=1.0)).groupby("blk").sum()
        Uw = allb.add(gg.u, fill_value=0); Bw = allb.add(gg.b, fill_value=0); Nw = allb.add(gg.n, fill_value=0)
        vw = (Uw - Bw) - dd * Nw; sed = np.sqrt(W / (W - 1) * (vw ** 2).sum()) / Nev
        r = out[f"DIR_{L}"]
        if not (np.isclose(r["K"][j], U) and np.isclose(r["E"][j], B, rtol=1e-9) and np.isclose(r["pp"][j], dd, rtol=1e-9) and np.isclose(r["se"][j], sed, rtol=1e-9)):
            ok = False; print("DIR mismatch", L, A.meta.cell[j], r["K"][j], U, r["E"][j], B, r["se"][j], sed)
print("STATS ENGINE == independent pandas groupby implementation (13 cells x 3 label sets x MOVE+DIR):", "PASS" if ok else "FAIL")
