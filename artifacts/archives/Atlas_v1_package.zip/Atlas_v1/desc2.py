"""D1 weekend-gap proxy, D4 pivots, D5 real-time trigger view, D6 event study, D7 gallery data, D8 onset map (PLAN section 7)."""
import numpy as np, pandas as pd, json, warnings
from zoneinfo import ZoneInfo
import common
warnings.filterwarnings("ignore"); common.check_plan()
df = common.load(); ts = df.index
o = df.open.to_numpy(float); h = df.high.to_numpy(float); l = df.low.to_numpy(float); c = df.close.to_numpy(float)
b = np.load("base.npz"); idx = b["idx"]; n = len(idx); dts = pd.DatetimeIndex(pd.to_datetime(b["dts_ns"], utc=True))
year = b["year"]; hour = b["hour"]; block = b["block"]; split = b["split"]
S = {}
# ---------------- D1 weekend gap proxy
tsv = ts.to_numpy(); lookup = pd.Series(np.arange(len(ts)), index=ts)
rows = []
d0 = pd.Timestamp("2021-01-01"); weeks = pd.date_range("2021-01-01", "2026-09-22", freq="D")
for day in weeks:
    if day.weekday() != 4: continue
    fri = pd.Timestamp(year=day.year, month=day.month, day=day.day, hour=16, tz=ZoneInfo("America/Chicago")).tz_convert("UTC")
    sun_d = day + pd.Timedelta(days=2)
    sun = pd.Timestamp(year=sun_d.year, month=sun_d.month, day=sun_d.day, hour=17, tz=ZoneInfo("America/Chicago")).tz_convert("UTC")
    try:
        i_f = lookup[fri - pd.Timedelta("5min")]; i_s = lookup[sun]
    except KeyError: continue
    rows.append((fri, sun, i_f, i_s))
wk = pd.DataFrame(rows, columns=["fri", "sun", "i_f", "i_s"])
wk["span_h"] = (wk.sun - wk.fri).dt.total_seconds() / 3600
wk["Pf"] = c[wk.i_f]; wk["Ps"] = o[wk.i_s]; wk["G"] = np.log(wk.Ps / wk.Pf)
def fill_info(i0, ref, gsign, horizons=(288, 864, 2016)):
    """first bar at/after i0 whose range touches ref; returns dict of filled within horizons + minutes to fill"""
    res = {}
    N = len(h); jmax = min(i0 + max(horizons), N - 1)
    seg_h = h[i0:jmax + 1]; seg_l = l[i0:jmax + 1]
    hit = (seg_l <= ref) if gsign > 0 else (seg_h >= ref)
    first = np.argmax(hit) if hit.any() else None
    for H in horizons: res[H] = bool(first is not None and first < H and i0 + H <= N - 1) if (i0 + H <= N - 1) else np.nan
    res["t_fill_h"] = (first * 5 / 60) if first is not None else np.nan
    return res
fi = [fill_info(r.i_s, r.Pf, np.sign(r.G)) for r in wk.itertuples()]
wk["fill24h"] = [x[288] for x in fi]; wk["fill72h"] = [x[864] for x in fi]; wk["fill7d"] = [x[2016] for x in fi]; wk["t_fill_h"] = [x["t_fill_h"] for x in fi]
wk["ret24h_toward"] = [(np.sign(-r.G) * np.log(c[min(r.i_s + 287, len(c) - 1)] / r.Ps)) for r in wk.itertuples()]
wk["abs_G_pct"] = np.abs(wk.G) * 100
# terciles
q = wk.abs_G_pct.quantile([1 / 3, 2 / 3]).to_numpy(); wk["bin"] = np.digitize(wk.abs_G_pct, q)
# placebo: every hourly time t outside Fri 21:00 - Sun 23:00 UTC, reference = close span hours earlier (span = median weekend span 49h)
span = int(round(wk.span_h.median() * 12))   # in bars
pj = np.arange(len(c)); pt = ts
cand = idx[(idx > span + 5)]  # D-point bars
cd = ts[cand]; wd = cd.dayofweek.to_numpy(); hh = cd.hour.to_numpy()
inwk = ((wd == 4) & (hh >= 20)) | (wd == 5) | ((wd == 6) & (hh <= 23))
cand = cand[~inwk][: -2016]  # leave 7d for fill horizon
pl = pd.DataFrame({"i": cand + 1})  # decision at close of bar -> "open" of next bar
pl = pl[pl.i < len(c) - 2017]
pl["Pf"] = c[pl.i - span - 1]; pl["Ps"] = o[pl.i]; pl["G"] = np.log(pl.Ps / pl.Pf); pl["abs_G_pct"] = pl.G.abs() * 100
sel = pl[(pl.abs_G_pct > 0.0)].copy()
# vectorised fill for placebo: first touch within 2016 bars
def fills_vec(i0, ref, sgn, H):
    out = np.zeros(len(i0), bool)
    for k in range(len(i0)):
        s = slice(i0[k], i0[k] + H)
        out[k] = (l[s] <= ref[k]).any() if sgn[k] > 0 else (h[s] >= ref[k]).any()
    return out
sg = np.sign(sel.G.to_numpy()); ii = sel.i.to_numpy(); rf = sel.Pf.to_numpy()
sel["fill24h"] = fills_vec(ii, rf, sg, 288); sel["fill72h"] = fills_vec(ii, rf, sg, 864); sel["fill7d"] = fills_vec(ii, rf, sg, 2016)
sel["bin"] = np.digitize(sel.abs_G_pct, q)
sel["ret24h_toward"] = np.sign(-sel.G.to_numpy()) * np.log(c[ii + 287] / o[ii])
def wilson(k, nn):
    if nn == 0: return (np.nan, np.nan)
    p = k / nn; z = 1.96; d = 1 + z * z / nn; ctr = (p + z * z / (2 * nn)) / d; hw = z * np.sqrt(p * (1 - p) / nn + z * z / (4 * nn * nn)) / d
    return (ctr - hw, ctr + hw)
out_rows = []
for bn, lab in enumerate(["small", "medium", "large"]):
    w = wk[wk.bin == bn]; p_ = sel[sel.bin == bn]
    r = dict(gap_size=lab, abs_G_range_pct=f"{w.abs_G_pct.min():.2f}-{w.abs_G_pct.max():.2f}", n_weekends=len(w), n_placebo=len(p_))
    for f in ("fill24h", "fill72h", "fill7d"):
        k = int(w[f].sum()); lo, hi = wilson(k, int(w[f].notna().sum()))
        r[f"wk_{f}"] = k / max(1, w[f].notna().sum()); r[f"wk_{f}_lo"] = lo; r[f"wk_{f}_hi"] = hi; r[f"pl_{f}"] = p_[f].mean()
    r["wk_median_t_fill_h"] = w.t_fill_h.median(); r["wk_toward_fill_ret24h_pct"] = w.ret24h_toward.mean() * 100; r["pl_toward_fill_ret24h_pct"] = p_.ret24h_toward.mean() * 100
    r["wk_toward_share"] = (w.ret24h_toward > 0).mean(); r["pl_toward_share"] = (p_.ret24h_toward > 0).mean()
    out_rows.append(r)
gp = pd.DataFrame(out_rows); gp.to_csv("D1_weekend_gap_summary.csv", index=False)
wk.drop(columns=["i_f", "i_s"]).to_csv("D1_weekend_gap_weeks.csv", index=False)
S["D1"] = dict(n_weekends=len(wk), median_span_h=float(wk.span_h.median()), median_abs_G_pct=float(wk.abs_G_pct.median()), p90_abs_G_pct=float(wk.abs_G_pct.quantile(.9)),
               frac_gap_up=float((wk.G > 0).mean()), tercile_edges_pct=[float(x) for x in q], fill_all_24h=float(wk.fill24h.mean()), fill_all_72h=float(wk.fill72h.mean()), fill_all_7d=float(wk.fill7d.mean()),
               placebo_fill_24h=float(sel.fill24h.mean()), placebo_fill_72h=float(sel.fill72h.mean()), placebo_fill_7d=float(sel.fill7d.mean()))
print(json.dumps(S["D1"], indent=1)); print(gp.round(3).T.to_string())

# ---------------- D4 pivots (ZigZag on hourly closes)
hc = c[idx]
def zigzag(x, thr):
    piv = []; mode = 0; ei = 0; ep = x[0]; lo_i = 0; lo_p = x[0]; hi_i = 0; hi_p = x[0]
    for i in range(1, len(x)):
        p = x[i]
        if mode == 0:
            if p > hi_p: hi_i, hi_p = i, p
            if p < lo_p: lo_i, lo_p = i, p
            if p >= lo_p * (1 + thr) and lo_i < i: piv.append((lo_i, -1, i)); mode = 1; ei, ep = i, p
            elif p <= hi_p * (1 - thr) and hi_i < i: piv.append((hi_i, 1, i)); mode = -1; ei, ep = i, p
        elif mode == 1:
            if p > ep: ei, ep = i, p
            elif p <= ep * (1 - thr): piv.append((ei, 1, i)); mode = -1; ei, ep = i, p
        else:
            if p < ep: ei, ep = i, p
            elif p >= ep * (1 + thr): piv.append((ei, -1, i)); mode = 1; ei, ep = i, p
    return pd.DataFrame(piv, columns=["j", "type", "confirm_j"])   # type -1 = pivot low (up-leg onset), +1 = pivot high
piv = {}
cells_meta = pd.read_csv("cells_meta.csv"); import scipy.sparse as sp
M = sp.load_npz("cellmat.npz").tocsr()
cname = list(cells_meta.cell); ci = {k: i for i, k in enumerate(cname)}
Mc = M.tocsc()
def cellvec(name): return np.asarray(Mc[:, ci[name]].todense()).ravel() > 0
pivrows = []
for thr in (0.02, 0.05):
    z = zigzag(hc, thr)
    z["next_j"] = z.j.shift(-1); z["leg_pct"] = (np.abs(np.log(hc[z.next_j.fillna(z.j).astype(int)] / hc[z.j])) * 100)
    z.loc[z.next_j.isna(), "leg_pct"] = np.nan
    z["dur_h"] = z.next_j - z.j; z["lag_h"] = z.confirm_j - z.j
    z["hour"] = hour[z.j]; z["dow"] = b["dow"][z.j]; z["year"] = year[z.j]
    piv[thr] = z
    z.assign(thr=thr, ts=dts[z.j].astype(str)).to_csv(f"D4_pivots_{int(thr*100)}pct.csv", index=False)
    for typ, nm in ((-1, "pivot_low(up-leg start)"), (1, "pivot_high(down-leg start)")):
        zz = z[(z.type == typ) & z.leg_pct.notna()]
        pivrows.append(dict(thr=thr, kind=nm, n=len(zz), leg_median_pct=zz.leg_pct.median(), leg_p90_pct=zz.leg_pct.quantile(.9), dur_median_h=zz.dur_h.median(), lag_median_h=zz.lag_h.median()))
pp = pd.DataFrame(pivrows); pp.to_csv("D4_pivot_leg_stats.csv", index=False); print(pp.round(2).to_string(index=False))
# feature lifts at pivots vs all D-points (indirect hour-of-day standardisation)
feat_cells = [k for k in cname if cells_meta.set_index("cell").loc[k, "family"] in ("VOL", "LOC", "CTX", "FLOW", "FVG") and not k.startswith("round")]
hr_base = pd.Series(1.0, index=range(24))
lift_rows = []
for thr in (0.02, 0.05):
    z = piv[thr]
    for typ, nm in ((-1, "pivot_low"), (1, "pivot_high")):
        js = z[(z.type == typ)].j.to_numpy(); nj = len(js)
        # expected share per cell given hour-of-day mix of pivots: sum_h share_h(pivots) * P(cell | hour h, all points)
        hp = np.bincount(hour[js], minlength=24) / nj
        for cname_ in feat_cells:
            v = cellvec(cname_); obs = v[js].mean()
            ph = np.array([v[hour == hh].mean() for hh in range(24)]); exp = float((hp * ph).sum())
            k = int(v[js].sum()); lo, hi = wilson(k, nj)
            lift_rows.append(dict(thr=thr, pivot=nm, n_pivots=nj, cell=cname_, obs_share=obs, exp_share_hour_adj=exp, lift=obs / exp if exp > 0 else np.nan, lift_lo=lo / exp if exp > 0 else np.nan, lift_hi=hi / exp if exp > 0 else np.nan, k=k))
pl_ = pd.DataFrame(lift_rows); pl_.to_csv("D4_pivot_feature_lifts.csv", index=False)
# hour distribution of pivots
hd = pd.DataFrame({f"{int(t*100)}%_{nm}": pd.Series(np.bincount(hour[piv[t][piv[t].type == ty].j], minlength=24) / (piv[t].type == ty).sum()) for t in piv for ty, nm in ((-1, "low"), (1, "high"))})
hd.index.name = "utc_hour"; hd.to_csv("D4_pivot_hour_share.csv")
S["D4"] = {str(t): dict(n_pivots=int(len(piv[t])), median_lag_h=float(piv[t].lag_h.median())) for t in piv}

# ---------------- D5 real-time view of trigger events (+2% before -1%, 24h) with calendar x year standardised baseline
H24 = 288
def first_touch(i0, up, dn, H):
    """first-passage of +up / -dn from close c[i0] using 5m highs/lows; ties in same bar -> 'loss' (conservative). returns code 1 win, -1 loss, 0 timeout (long); mirrored for short by symmetry"""
    N = len(c); out = np.zeros(len(i0), np.int8)
    base = c[i0]; hi_t = base * (1 + up); lo_t = base * (1 - dn)
    alive = np.ones(len(i0), bool)
    for k in range(1, H + 1):
        j = np.minimum(i0 + k, N - 1)
        w = alive & (h[j] >= hi_t); lz = alive & (l[j] <= lo_t)
        both = w & lz
        out[lz] = -1; out[w & ~lz] = 1; alive &= ~(w | lz)
        if not alive.any(): break
    return out
valid = idx + H24 <= len(c) - 1
long_res = np.zeros(n, np.int8); short_res = np.zeros(n, np.int8)
vi = np.where(valid)[0]
long_res[vi] = first_touch(idx[vi], 0.02, 0.01, H24)
# short: +2% down before -1%... mirror by working with lows/highs
def first_touch_short(i0, dn, up, H):
    N = len(c); out = np.zeros(len(i0), np.int8); base = c[i0]; lo_t = base * (1 - dn); hi_t = base * (1 + up); alive = np.ones(len(i0), bool)
    for k in range(1, H + 1):
        j = np.minimum(i0 + k, N - 1)
        w = alive & (l[j] <= lo_t); lz = alive & (h[j] >= hi_t)
        out[lz] = -1; out[w & ~lz] = 1; alive &= ~(w | lz)
        if not alive.any(): break
    return out
short_res[vi] = first_touch_short(idx[vi], 0.02, 0.01, H24)
mfe = np.full(n, np.nan); mae = np.full(n, np.nan)
for k0 in range(0, len(vi), 5000):
    ii_ = vi[k0:k0 + 5000]
    W = np.stack([h[idx[ii_] + k] for k in range(1, H24 + 1)], 1); Lw = np.stack([l[idx[ii_] + k] for k in range(1, H24 + 1)], 1)
    mfe[ii_] = np.log(W.max(1) / c[idx[ii_]]); mae[ii_] = np.log(Lw.min(1) / c[idx[ii_]])
cal = hour * 2 + (b["dow"] >= 5)
key = year * 100 + cal
def standardised(y, m):
    """expected mean of y for members of m, from year x calendar mean over all valid points"""
    dfy = pd.DataFrame({"k": key[vi], "y": y[vi]}); mu = dfy.groupby("k").y.mean()
    return mu.reindex(key[m & valid]).mean()
events = ["BOUNCE_UP", "BOUNCE_DN", "BREAK_UP_288", "BREAK_DN_288", "SWEEP_UP_288", "SWEEP_DN_288", "BREAK_UP_2016", "BREAK_DN_2016", "SWEEP_UP_2016", "SWEEP_DN_2016", "NR24", "WR24"]
rng = np.random.default_rng(11)
ub, binv = np.unique(block, return_inverse=True)
def boot_diff(y, e, mu_key, nb=1000):
    # cluster bootstrap by week-block of mean(y|event) - mean(expected|event)
    yy = y.astype(float); ex = pd.Series(mu_key).reindex(key).to_numpy()
    d = (yy - ex) * e * valid; cnt = (e & valid).astype(float)
    ds = np.bincount(binv, weights=d, minlength=len(ub)); cs = np.bincount(binv, weights=cnt, minlength=len(ub))
    out = []
    for _ in range(nb):
        s = rng.integers(0, len(ub), len(ub)); out.append(ds[s].sum() / max(cs[s].sum(), 1))
    return np.percentile(out, [2.5, 97.5])
rows = []
for ev in events + ["ALL"]:
    m = np.ones(n, bool) if ev == "ALL" else cellvec(ev)
    mm = m & valid
    r = dict(event=ev, n=int(mm.sum()))
    for nm, y in (("long_win_2v1", (long_res == 1).astype(float)), ("long_loss", (long_res == -1).astype(float)), ("short_win_2v1", (short_res == 1).astype(float)), ("short_loss", (short_res == -1).astype(float))):
        mu = pd.DataFrame({"k": key[vi], "y": y[vi]}).groupby("k").y.mean()
        r[nm] = float(y[mm].mean()); r[nm + "_expected"] = float(standardised(y, m)); lo, hi = boot_diff(y, m, mu)
        r[nm + "_diff_lo"] = float(lo); r[nm + "_diff_hi"] = float(hi)
    r["mfe_med_pct"] = float(np.exp(np.nanmedian(mfe[mm])) * 100 - 100); r["mae_med_pct"] = float(100 - np.exp(np.nanmedian(mae[mm])) * 100)
    r["mfe_p90_pct"] = float(np.exp(np.nanpercentile(mfe[mm], 90)) * 100 - 100); r["mae_p90_pct"] = float(100 - np.exp(np.nanpercentile(mae[mm], 10)) * 100)
    rows.append(r)
d5 = pd.DataFrame(rows); d5.to_csv("D5_trigger_realtime_2v1_24h.csv", index=False)
print(d5.round(3).to_string(index=False))
np.savez_compressed("D5_arrays.npz", long_res=long_res, short_res=short_res, mfe=mfe, mae=mae)
json.dump(S, open("desc2_summary.json", "w"), indent=1, default=float)
