"""D6 event study, D7 gallery selection, D8 onset map data."""
import numpy as np, pandas as pd, json, warnings
import common
warnings.filterwarnings("ignore"); common.check_plan()
df = common.load(); ts = df.index
h = df.high.to_numpy(float); l = df.low.to_numpy(float); c = df.close.to_numpy(float)
b = np.load("base.npz"); idx = b["idx"]; n = len(idx); dts = pd.DatetimeIndex(pd.to_datetime(b["dts_ns"], utc=True))
block = b["block"]; hour = b["hour"]; year = b["year"]
hc = c[idx]
r5 = np.r_[np.nan, np.diff(np.log(c))]
ss288 = pd.Series(r5 ** 2).rolling(288).sum().to_numpy(); sig = np.sqrt(ss288)[idx]
lab = b["L2"]
M = np.arange(-48, 25)
J = np.arange(n)[:, None] + M[None, :]
ok = (J >= 0) & (J < n)
Jc = np.clip(J, 0, n - 1)
path = np.log(hc[Jc] / hc[:, None]) / sig[:, None]
path[~ok] = np.nan
feats = {"ln_range12": b["f_ln_range12"], "VR": b["f_VR"]}
fpath = {k: np.where(ok, v[Jc], np.nan) for k, v in feats.items()}
ub, binv = np.unique(block, return_inverse=True)
rng = np.random.default_rng(3)
rows = []
groups = {"UP": lab == 1, "DOWN": lab == -1, "NONE": lab == 0}
valid = np.isfinite(sig) & (lab != -9)
def boot_mean(arr, m, nb=300):
    A = np.where(m[:, None], arr, np.nan)
    cnt = np.bincount(binv, weights=(m & True).astype(float), minlength=len(ub))
    out = []
    S = np.zeros((len(ub), arr.shape[1])); C = np.zeros((len(ub), arr.shape[1]))
    for t in range(arr.shape[1]):
        col = A[:, t]; f = np.isfinite(col)
        S[:, t] = np.bincount(binv[f], weights=col[f], minlength=len(ub)); C[:, t] = np.bincount(binv[f], minlength=len(ub))
    est = S.sum(0) / np.maximum(C.sum(0), 1)
    bs = np.empty((nb, arr.shape[1]))
    for k in range(nb):
        s = rng.integers(0, len(ub), len(ub)); bs[k] = S[s].sum(0) / np.maximum(C[s].sum(0), 1)
    return est, np.percentile(bs, 2.5, 0), np.percentile(bs, 97.5, 0)
for g, m in groups.items():
    m = m & valid
    est, lo, hi = boot_mean(path, m)
    med = np.nanmedian(np.where(m[:, None], path, np.nan), axis=0)
    e2, l2, h2 = boot_mean(fpath["ln_range12"], m); e3, l3, h3 = boot_mean(fpath["VR"], m & np.isfinite(b["f_VR"]))
    for k, mm in enumerate(M):
        rows.append(dict(group=g, m_hours=mm, n=int(m.sum()), mean=est[k], lo=lo[k], hi=hi[k], median=med[k], ln_range12=e2[k], ln_range12_lo=l2[k], ln_range12_hi=h2[k], VR=e3[k], VR_lo=l3[k], VR_hi=h3[k]))
pd.DataFrame(rows).to_csv("D6_event_study.csv", index=False)
print(pd.DataFrame(rows).query("m_hours in (-24,-6,-1,0,1,4,8,24)")[["group", "m_hours", "n", "mean", "lo", "hi", "median", "ln_range12", "VR"]].round(3).to_string(index=False))
# ---- D8 onset runs (L2)
mv = (lab != 0) & (lab != -9)
start = mv & ~np.r_[False, mv[:-1]]
on = pd.DataFrame({"j": np.where(start)[0]}); on["ts"] = dts[on.j]; on["dir"] = lab[on.j]; on["t_to_breach_h"] = b["L2_t"][on.j] * 5 / 60
on.to_csv("D8_onsets_L2.csv", index=False)
print("onset runs:", len(on), " UP", int((on.dir == 1).sum()), "DOWN", int((on.dir == -1).sum()), " median hours to breach", on.t_to_breach_h.median())
by = on.groupby(on.ts.dt.year).dir.agg(n="size", up=lambda s: (s == 1).sum()); print(by.T.to_string())
# ---- D7 gallery selection from ZigZag 2% pivots
z = pd.read_csv("D4_pivots_2pct.csv")
H24 = 288; rows = []
for r in z.itertuples():
    i0 = idx[r.j]
    if i0 + H24 >= len(c) or i0 < 300: continue
    if r.type == -1: ex = np.log(h[i0 + 1:i0 + H24 + 1].max() / c[i0]); typ = "UP"
    else: ex = -np.log(l[i0 + 1:i0 + H24 + 1].min() / c[i0]); typ = "DOWN"
    rows.append(dict(j=r.j, i0=i0, dir=typ, exc24_pct=(np.exp(abs(ex)) - 1) * 100, exc_sigma=abs(ex) / sig[r.j] if np.isfinite(sig[r.j]) else np.nan, ts=dts[r.j]))
gz = pd.DataFrame(rows)
sel = []
for typ in ("UP", "DOWN"):
    g = gz[gz.dir == typ].sort_values("exc_sigma", ascending=False)
    taken = []
    for r in g.itertuples():
        if all(abs(r.j - t.j) >= 24 for t in taken): taken.append(r)
        if len(taken) == 12: break
    sel += taken
gal = pd.DataFrame(sel)
ed = json.load(open("edges.json"))
def binof(name, v):
    e = ed[name]; return int(np.digitize(v, e)) + 1
gal["hour_utc"] = [dts[j].hour for j in gal.j]; gal["weekday"] = [dts[j].day_name()[:3] for j in gal.j]
gal["range12_bin"] = [binof("ln_range12", b["f_ln_range12"][j]) for j in gal.j]
gal["VR_bin"] = [binof("VR", b["f_VR"][j]) if np.isfinite(b["f_VR"][j]) else np.nan for j in gal.j]
gal["ctx48_bin"] = [binof("ctx48", b["f_ctx48"][j]) if np.isfinite(b["f_ctx48"][j]) else np.nan for j in gal.j]
gal["TI48_bin"] = [binof("TI48", b["f_TI48"][j]) for j in gal.j]
gal["pos24_bin"] = [binof("pos24", b["f_pos24"][j]) for j in gal.j]
gal["ts"] = gal.ts.astype(str); gal.to_csv("D7_gallery_events.csv", index=False)
print(gal[["dir", "ts", "weekday", "exc24_pct", "exc_sigma", "range12_bin", "VR_bin", "ctx48_bin", "TI48_bin", "pos24_bin"]].round(1).to_string(index=False))
