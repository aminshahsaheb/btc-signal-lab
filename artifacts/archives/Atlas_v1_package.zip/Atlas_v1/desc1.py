"""D2 timing, D3 concentration, single-feature AUC ranking (PLAN sections 4 and 7)."""
import numpy as np, pandas as pd, json, warnings
from scipy.stats import rankdata
import common
warnings.filterwarnings("ignore"); common.check_plan()
df = common.load(); c = df.close.to_numpy(float); ts = df.index
b = np.load("base.npz"); out = {}
r5 = np.r_[np.nan, np.diff(np.log(c))]; q = r5 ** 2
# ---------- D2 timing
hr = ts.hour.to_numpy(); yr = ts.year.to_numpy()
off = pd.Series(ts.tz_convert("America/New_York").map(lambda x: x.utcoffset().total_seconds())).to_numpy()
summer = off == -4 * 3600
tot = np.nansum(q)
share_all = pd.Series(q).groupby(hr).sum() / tot
share_sum = pd.Series(q[summer]).groupby(hr[summer]).sum() / np.nansum(q[summer])
share_win = pd.Series(q[~summer]).groupby(hr[~summer]).sum() / np.nansum(q[~summer])
byyr = pd.DataFrame({y: pd.Series(q[yr == y]).groupby(hr[yr == y]).sum() / np.nansum(q[yr == y]) for y in np.unique(yr)})
tim = pd.DataFrame({"all": share_all, "usSummer": share_sum, "usWinter": share_win}).join(byyr.add_prefix("y"))
tim.index.name = "utc_hour"; tim.to_csv("D2_hour_share_of_variance.csv")
# hour of daily high/low
day = ts.floor("1D"); dfh = pd.DataFrame({"h": df.high.to_numpy(), "l": df.low.to_numpy(), "day": day, "hr": hr})
g = dfh.groupby("day"); hi_hr = g.apply(lambda x: x.hr.iloc[int(np.argmax(x.h.to_numpy()))]); lo_hr = g.apply(lambda x: x.hr.iloc[int(np.argmin(x.l.to_numpy()))])
full_days = g.size() == 288
hl = pd.DataFrame({"high_hour_share": hi_hr[full_days].value_counts(normalize=True).sort_index(), "low_hour_share": lo_hr[full_days].value_counts(normalize=True).sort_index()})
hl.index.name = "utc_hour"; hl.to_csv("D2_daily_high_low_hour.csv")
# ---------- D3 concentration
dv = pd.Series(q).groupby(day).sum(); dv = dv[full_days]
s = dv.sort_values(ascending=False); T = s.sum(); nd = len(s)
conc = {"n_days": nd, "top1pct_days_share": float(s.iloc[:max(1, int(round(.01 * nd)))].sum() / T), "top5pct_days_share": float(s.iloc[:int(round(.05 * nd))].sum() / T),
        "top10pct_days_share": float(s.iloc[:int(round(.10 * nd))].sum() / T), "top20_days_share": float(s.iloc[:20].sum() / T), "top1pct_n": int(round(.01 * nd)), "top5pct_n": int(round(.05 * nd)), "top10pct_n": int(round(.10 * nd))}
# benchmark: a calm 'gaussian with same total' would give top-5% share of ~0.1 -> report iid-gaussian-scaled benchmark via shuffling returns within year
rng = np.random.default_rng(1); bench = []
for _ in range(20):
    qq = q.copy(); 
    for y in np.unique(yr):
        m = np.where(yr == y)[0]; qq[m] = rng.permutation(qq[m])
    dd = pd.Series(qq).groupby(day).sum()[full_days].sort_values(ascending=False); bench.append(float(dd.iloc[:int(round(.05 * nd))].sum() / dd.sum()))
conc["top5pct_share_if_bars_shuffled_within_year"] = float(np.mean(bench))
dayrng = dfh.groupby("day").apply(lambda x: np.log(x.h.max() / x.l.min()))
dayret = pd.Series(c, index=ts).groupby(day).last().pipe(lambda x: np.log(x / pd.Series(df.open.to_numpy(), index=ts).groupby(day).first()))
top = pd.DataFrame({"var_share": s / T, "range_pct": dayrng.reindex(s.index) * 100, "ret_pct": dayret.reindex(s.index) * 100}).head(30)
top["weekday"] = top.index.day_name().str[:3]; top.index = top.index.strftime("%Y-%m-%d"); top.to_csv("D3_top30_days.csv")
bars = pd.DataFrame({"ret_pct": r5 * 100, "abs": np.abs(r5)}, index=ts).sort_values("abs", ascending=False).head(20).drop(columns="abs"); bars.index = bars.index.strftime("%Y-%m-%d %H:%M"); bars.to_csv("D3_top20_5m_bars.csv")
by_year = {int(y): float(pd.Series(q[yr == y]).groupby(day[yr == y]).sum().pipe(lambda x: x.sort_values(ascending=False).iloc[:max(1, int(round(.05 * len(x))))].sum() / x.sum())) for y in np.unique(yr)}
conc["top5pct_days_share_by_year"] = by_year
# daily vol of hourly... realised vol annualised per year
conc["ann_vol_by_year"] = {int(y): float(np.sqrt(np.nansum(q[yr == y]) / (yr == y).sum() * 105120)) for y in np.unique(yr)}
out["concentration"] = conc
# ---------- AUC ranking (within year x hour strata)
def strat_auc(x, y, strata):
    num = den = 0.0
    for s_ in np.unique(strata):
        m = (strata == s_) & np.isfinite(x)
        yy = y[m]; n1 = yy.sum(); n0 = len(yy) - n1
        if n1 < 10 or n0 < 10: continue
        rk = rankdata(x[m]); auc = (rk[yy == 1].sum() - n1 * (n1 + 1) / 2) / (n1 * n0)
        w = n1 * n0; num += w * auc; den += w
    return num / den if den else np.nan
feats = ["ln_range12", "ln_range288", "compress", "varratio", "pos24", "pos7d", "dayopen_z", "weekopen_z", "round_dist", "ctx12", "ctx48", "ctx288", "ctx2016", "VR", "ABS", "TI12", "TI48", "TI288"]
rows = []
split = b["split"]; hour = b["hour"]; year = b["year"]
for f in feats:
    x = b["f_" + f].astype(float)
    row = {"feature": f}
    for L in ("L1", "L2", "L3"):
        d = b[L]; valid = d != -9; y = ((d != 0) & valid).astype(int)
        m = valid
        row[f"AUC_move_{L}_raw"] = strat_auc(x[m], y[m], np.zeros(m.sum()))
        row[f"AUC_move_{L}_adj"] = strat_auc(x[m], y[m], (year[m] * 100 + hour[m]))
        ev = valid & (d != 0); yu = (d[ev] == 1).astype(int)
        row[f"AUC_dir_{L}"] = strat_auc(x[ev], yu, year[ev])
    rows.append(row)
auc = pd.DataFrame(rows); auc.to_csv("AUC_single_feature.csv", index=False)
# anchor vs ledger: frozen MO weights on CONF window, L2 MOVE, hourly D-points
sc_ = 6.1229 + 0.7789 * b["f_ln_range12"] + 0.9486 * b["f_ln_range288"]
d = b["L2"]; m = (b["split"] == 1) & (d != -9); y = (d[m] != 0).astype(int)
rk = rankdata(sc_[m]); n1 = y.sum(); n0 = len(y) - n1
out["MO_anchor_AUC_conf_hourly"] = float((rk[y == 1].sum() - n1 * (n1 + 1) / 2) / (n1 * n0)); out["MO_anchor_note"] = "ledger AUC on all 5m bars of confirmation window = 0.6721"
json.dump(out, open("desc1_summary.json", "w"), indent=1, default=float)
print(json.dumps(out, indent=1, default=float)); print(auc.round(3).to_string(index=False))
print(tim.round(4).head(24).to_string()); print(hl.round(3).T.to_string())
print(top.head(12).round(2).to_string())
