"""Cell statistics of the Move-Onset Atlas (PLAN.md section 4). Pure numpy/scipy.sparse."""
import numpy as np, pandas as pd, scipy.sparse as sp
from scipy.stats import norm
import common

class Atlas:
    def __init__(self, folder="."):
        b = np.load(f"{folder}/base.npz")
        self.b = b; self.N = len(b["hour"])
        self.hour = b["hour"]; self.dow = b["dow"]; self.year = b["year"]; self.block = b["block"]; self.split = b["split"]
        self.meta = pd.read_csv(f"{folder}/cells_meta.csv"); self.C = len(self.meta)
        self.M = sp.load_npz(f"{folder}/cellmat.npz").tocsr().astype(float)
        N = self.N
        ub, binv = np.unique(self.block, return_inverse=True); self.W = len(ub); self.ub = ub
        self.B = sp.csr_matrix((np.ones(N), (binv, np.arange(N))), shape=(self.W, N))
        self.years = np.unique(self.year); yi = np.searchsorted(self.years, self.year); self.yi = yi
        self.Y = sp.csr_matrix((np.ones(N), (yi, np.arange(N))), shape=(len(self.years), N))
        self.S = sp.csr_matrix((np.ones(N), (self.split, np.arange(N))), shape=(3, N))
        self.cal = self.hour * 2 + (self.dow >= 5).astype(int)
        self.disc = self.split == 0
        self.flat = (self.meta["kind"] == "hd").to_numpy()
        self.labs = {L: b[L] for L in ("L1", "L2", "L3")}

    def _sums(self, a):
        Ma = sp.diags(a) @ self.M
        return (self.B @ Ma).toarray(), (self.Y @ Ma).toarray(), (self.S @ Ma).toarray()

    def run(self, labs=None, detail=True):
        labs = labs or self.labs; out = {}
        W = self.W
        for L in ("L1", "L2", "L3"):
            d = labs[L]; valid = d != -9; v = valid.astype(float)
            y = ((d != 0) & valid).astype(float)
            m = self.disc & valid
            num = np.bincount(self.cal[m], weights=y[m], minlength=48); den = np.bincount(self.cal[m], minlength=48)
            pc = np.where(den > 0, num / np.maximum(den, 1), y[m].mean())
            pcal = pc[self.cal]
            ysum = np.bincount(self.yi, weights=y, minlength=len(self.years)); yn = np.bincount(self.yi, weights=v, minlength=len(self.years))
            ycal = np.bincount(self.yi, weights=pcal * v, minlength=len(self.years))
            s_y = ysum / np.maximum(ycal, 1e-12); rate_y = ysum / np.maximum(yn, 1)
            e_cal = pcal * s_y[self.yi] * v; e_flat = rate_y[self.yi] * v
            e_pool = pcal * (y.sum() / (pcal * v).sum()) * v
            Kw, Ky, Ks = self._sums(y); nW, nY, nS = self._sums(v)
            Ecw, Ecy, Ecs = self._sums(e_cal); Efw, Efy, Efs = self._sums(e_flat); Epw, _, _ = self._sums(e_pool)
            fl = self.flat[None, :]
            Ew = np.where(fl, Efw, Ecw); Ey = np.where(fl, Efy, Ecy); Es = np.where(fl, Efs, Ecs)
            K = Kw.sum(0); E = Ew.sum(0); n = nW.sum(0)
            with np.errstate(all="ignore"):
                lift = K / E
                u = Kw / K - Ew / E
                se = np.sqrt(W / (W - 1) * (u ** 2).sum(0))
                z = np.log(lift) / se
                testable = (K >= 30) & (E >= 30)
                z = np.where(testable & np.isfinite(z), z, np.nan)
                res = dict(n=n, K=K, E=E, lift=lift, se=se, z=z, p=2 * norm.sf(np.abs(z)), pp=(K - E) / n,
                           rate=K / n, lift_pool=K / Epw.sum(0), lift_raw=(K / n) / (y.sum() / v.sum()), testable=testable)
                ly = np.where(Ey >= 8, Ky / Ey, np.nan); ls = np.where(Es >= 8, Ks / Es, np.nan)
                sg = np.sign(np.log(lift))
                res["ly"] = ly; res["ls"] = ls
                res["n_elig_y"] = np.isfinite(ly).sum(0); res["n_agree_y"] = (np.isfinite(ly) & (np.sign(np.log(ly)) == sg[None, :])).sum(0)
                res["n_elig_s"] = np.isfinite(ls).sum(0); res["n_agree_s"] = (np.isfinite(ls) & (np.sign(np.log(ls)) == sg[None, :])).sum(0)
            out[f"MOVE_{L}"] = res
            # direction
            ev = (valid & (d != 0)); evf = ev.astype(float); up = ((d == 1) & valid).astype(float)
            uy = np.bincount(self.yi, weights=up, minlength=len(self.years)); ey = np.bincount(self.yi, weights=evf, minlength=len(self.years))
            sh_y = uy / np.maximum(ey, 1); sh_all = up.sum() / evf.sum()
            bv = sh_y[self.yi] * evf; bpool = sh_all * evf
            Uw, Uy, Us = self._sums(up); Evw, Evy, Evs = self._sums(evf); Bw, By, Bs = self._sums(bv); Bpw, _, _ = self._sums(bpool)
            U = Uw.sum(0); Ev = Evw.sum(0); B = Bw.sum(0)
            with np.errstate(all="ignore"):
                dd = (U - B) / Ev
                vw = (Uw - Bw) - dd[None, :] * Evw
                se = np.sqrt(W / (W - 1) * (vw ** 2).sum(0)) / Ev
                z = dd / se; testable = Ev >= 40
                z = np.where(testable & np.isfinite(z), z, np.nan)
                res = dict(n=Ev, K=U, E=B, lift=U / Ev, se=se, z=z, p=2 * norm.sf(np.abs(z)), pp=dd, rate=U / Ev,
                           lift_pool=(U - Bpw.sum(0)) / Ev, lift_raw=U / Ev - sh_all, testable=testable)
                dy = np.where(Evy >= 15, (Uy - By) / Evy, np.nan); ds = np.where(Evs >= 15, (Us - Bs) / Evs, np.nan)
                sg = np.sign(dd)
                res["ly"] = dy; res["ls"] = ds
                res["n_elig_y"] = np.isfinite(dy).sum(0); res["n_agree_y"] = (np.isfinite(dy) & (np.sign(dy) == sg[None, :])).sum(0)
                res["n_elig_s"] = np.isfinite(ds).sum(0); res["n_agree_s"] = (np.isfinite(ds) & (np.sign(ds) == sg[None, :])).sum(0)
            out[f"DIR_{L}"] = res
        return out

def shifted(labs, k):
    return {L: np.roll(labs[L], -k) for L in labs}   # label of point i is taken from point i+k (circular)
