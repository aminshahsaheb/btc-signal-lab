import numpy as np, pandas as pd, json, warnings
from figstyle import *
import common
warnings.filterwarnings("ignore"); common.check_plan()
T = pd.read_csv("atlas_tiers.csv")
df = common.load(); ts = df.index
# ---------- F8 hindsight vs real-time
L = pd.read_csv("D4_pivot_feature_lifts.csv")
cells = [("BREAK_DN_288", "closes below the 24 h low"), ("BREAK_DN_2016", "closes below the 7 d low"), ("SWEEP_DN_288", "sweeps the 24 h low and closes back"), ("ln_range12_b4", "hot hour (top-20% range)"),
         ("VR_b4", "volume surge (top 20%)"), ("pos24_b0", "at the bottom of the 24 h range"), ("TI48_b0", "heavy taker selling (4 h)"), ("ctx48_b0", "sharp fall in last 4 h")]
fig, axs = plt.subplots(1, 2, figsize=(14, 5.2), sharey=True)
yy = np.arange(len(cells))[::-1]
for y, (c, nm) in zip(yy, cells):
    r = L[(L["thr"] == 0.02) & (L["pivot"] == "pivot_low") & (L.cell == c)].iloc[0]
    axs[0].barh(y, r.lift, height=0.55, color=UPC); axs[0].hlines(y, r.lift_lo, r.lift_hi, color=INK, lw=1.2); axs[0].text(max(r.lift_hi, r.lift) * 1.1, y, f"{r.lift:.1f}×", va="center", fontsize=9, color=INK2)
    d = T[(T.outcome == "DIR_L2") & (T.cell == c)].iloc[0]
    axs[1].errorbar(d.pp * 100, y, xerr=1.96 * d.se * 100, fmt="o", color=VIOLET, ms=7, lw=1.5, capsize=2.5, mec=SURF, mew=1.3)
axs[0].set_xscale("log"); axs[0].axvline(1, color=INK2, lw=1); axs[0].set_xlim(0.04, 60); axs[0].set_xticks([0.1, 1, 10]); axs[0].get_xaxis().set_major_formatter(matplotlib.ticker.FuncFormatter(lambda v, _: f"{v:g}×")); axs[0].xaxis.set_minor_formatter(matplotlib.ticker.NullFormatter())
axs[0].set_yticks(yy); axs[0].set_yticklabels([nm for _, nm in cells], fontsize=9.5); axs[0].set_title("Hindsight: over-representation at 884 swing lows")
axs[1].axvspan(-3, 3, color=GRID, alpha=0.6, lw=0); axs[1].axvline(0, color=INK2, lw=1); axs[1].set_xlim(-12, 12); axs[1].set_title("Real time: UP-share after the same state"); axs[1].set_xlabel("UP-share minus baseline (pp)")
for a in axs: a.grid(axis="y", visible=False)
note(fig, "A swing low is by definition the lowest close, so 'closing below the 24 h low' is ~9× over-represented there (32% of lows vs 3.6% of hours). That looks like a signal on the chart, but the same event seen live is followed by up and down moves almost equally (a slight lean of −2 to −7 pp toward further DOWN, not a bounce). Selection by outcome, not information.", y=-0.01)
save(fig, "F08_hindsight_vs_realtime")
# lag histogram
fig, axs = plt.subplots(1, 2, figsize=(12, 3.8))
for ax, thr, nm in ((axs[0], 2, "2% swings"), (axs[1], 5, "5% swings")):
    z = pd.read_csv(f"D4_pivots_{thr}pct.csv")
    ax.hist(z.lag_h.clip(upper=72 if thr == 5 else 36), bins=np.arange(0, 74 if thr == 5 else 38, 2 if thr == 5 else 1), color=BLUE, rwidth=0.9)
    ax.axvline(z.lag_h.median(), color=ORANGE, lw=1.6); ax.text(z.lag_h.median() + 0.5, ax.get_ylim()[1] * 0.9, f"median {z.lag_h.median():.0f} h", color=INK2, fontsize=9)
    ax.set_title(f"Hours until a {nm} low/high is KNOWN"); ax.set_xlabel("hours after the actual extreme"); ax.set_ylabel("count")
note(fig, "The swing point you see on the chart is only confirmed after the market has already reversed by the threshold; the median lag is 6–7 h for 2% swings and ≈ 21–23 h for 5% swings.", y=-0.02)
save(fig, "F09_confirmation_lag")
# ---------- F10 weekend gap
G = pd.read_csv("D1_weekend_gap_summary.csv")
fig, axs = plt.subplots(1, 3, figsize=(14, 4.4), sharey=True)
for ax, (f, nm) in zip(axs, (("fill24h", "within 24 h"), ("fill72h", "within 3 days"), ("fill7d", "within 7 days"))):
    x = np.arange(3)
    ax.bar(x - 0.2, G[f"wk_{f}"] * 100, width=0.38, color=BLUE, label="real weekends (n≈100 per size group)")
    ax.vlines(x - 0.2, G[f"wk_{f}_lo"] * 100, G[f"wk_{f}_hi"] * 100, color=INK, lw=1.2)
    ax.bar(x + 0.2, G[f"pl_{f}"] * 100, width=0.38, color=MUTED, label="same-size 49 h displacement at any other time")
    ax.set_xticks(x); ax.set_xticklabels(["small gap\n(<0.5%)", "medium\n(0.5–1.6%)", "large\n(>1.6%)"]); ax.set_title(f"Gap closed {nm}")
axs[0].set_ylabel("% of cases price trades back to Friday's level"); h_, l_ = axs[0].get_legend_handles_labels(); fig.legend(h_, l_, loc="lower center", ncol=2, fontsize=9.5, bbox_to_anchor=(0.5, -0.04))
note(fig, "Weekend 'CME gap' proxy = Binance price at Sun 17:00 CT vs Fri 16:00 CT (real CME futures prices are not available here). Gaps are filled about as often as any other displacement of the same size — no special magnet; whiskers = 95% Wilson band. Large gaps (>1.6%) fill more often than the placebo (37% vs 22% in 24 h, 55% vs 42% in 3 d) — one size group of three; a hint, not a rule.", y=-0.09)
save(fig, "F10_weekend_gap")
# ---------- F11 concentration
r5 = np.r_[np.nan, np.diff(np.log(df.close.to_numpy(float)))]; q = r5 ** 2
day = ts.floor("1D"); dv = pd.Series(q).groupby(day).sum(); dv = dv[pd.Series(1, index=ts).groupby(day).sum() == 288]
s = dv.sort_values(ascending=False); cum = s.cumsum() / s.sum(); xs = np.arange(1, len(s) + 1) / len(s) * 100
rng = np.random.default_rng(1); yr = ts.year.to_numpy(); curves = []
for _ in range(10):
    qq = q.copy()
    for y in np.unique(yr):
        m = np.where(yr == y)[0]; qq[m] = rng.permutation(qq[m])
    d2 = pd.Series(qq).groupby(day).sum()[dv.index].sort_values(ascending=False); curves.append(d2.cumsum().to_numpy() / d2.sum())
bench = np.mean(curves, 0)
fig, axs = plt.subplots(1, 2, figsize=(14, 4.8), gridspec_kw=dict(width_ratios=[1, 1.15]))
axs[0].plot(xs, cum.values * 100, color=BLUE, label="real market"); axs[0].plot(xs, bench * 100, color=MUTED, label="same 5-min returns shuffled within each year"); axs[0].plot([0, 100], [0, 100], color=AXIS, lw=1)
for p in (1, 5, 10):
    i = int(round(p / 100 * len(s))) - 1; axs[0].scatter([xs[i]], [cum.values[i] * 100], color=BLUE, s=40, zorder=5, edgecolor=SURF, linewidth=1.5); axs[0].text(xs[i] + 1.5, cum.values[i] * 100 - 4, f"top {p}% of days → {cum.values[i]*100:.0f}%", fontsize=9, color=INK2)
axs[0].set_xlim(0, 40); axs[0].set_ylim(0, 70); axs[0].set_xlabel("% of days (busiest first)"); axs[0].set_ylabel("% of all movement (sum of squared 5-min returns)"); axs[0].legend(loc="lower right", fontsize=9); axs[0].set_title("A few days hold a large share of all movement")
top = pd.read_csv("D3_top30_days.csv").head(12)
axs[1].barh(np.arange(12)[::-1], top.var_share * 100, color=BLUE, height=0.6)
for i, r in enumerate(top.itertuples()): axs[1].text(r.var_share * 100 + 0.05, 11 - i, f"{r.timestamp}  {r.weekday}   range {r.range_pct:.0f}%, close {r.ret_pct:+.0f}%", va="center", fontsize=8.5, color=INK2)
axs[1].set_yticks([]); axs[1].set_xlim(0, 6.6); axs[1].set_xlabel("% of the whole 5.7-year movement in a single day"); axs[1].set_title("The 12 busiest days"); axs[1].grid(axis="y", visible=False)
note(fig, "The 21 busiest days (1%) hold 15% of all movement, the busiest 105 days (5%) hold 34% — vs 18% if bar-level moves were spread randomly within each year. Big moves are not evenly sprinkled: they come in clusters and in a handful of violent days (e.g. 19 May 2021: 42% range; 17 Aug 2023; 10 Oct 2025).", y=-0.02)
save(fig, "F11_concentration")
# ---------- F13 placebo calibration
P = pd.read_csv("placebo_summary.csv"); mx = {}
for (f, t), g in T[(T.family != "CALEV")].groupby(["family", T.outcome.str[:4].map({"MOVE": "MOVE", "DIR_": "DIR"})]):
    if f == "CAL": g = g[g.kind == "hd"]
    mx[(f, t)] = g.z.abs().max()
fig, ax = plt.subplots(figsize=(11, 5.8)); rows = list(P.itertuples()); n = len(rows)
for i, r in enumerate(rows):
    y = n - 1 - i
    ax.hlines(y, 0, r.placebo_p95_maxabsz, color=MUTED, lw=7, alpha=0.5, capstyle="butt"); ax.scatter(r.placebo_mean_maxabsz, y, color=INK2, s=28, zorder=4)
    ax.scatter(r.bonf_z, y, marker="|", s=240, color=ORANGE, zorder=5)
    ax.scatter(mx[(r.family, r.type)], y, color=BLUE, s=60, zorder=6, edgecolor=SURF, linewidth=1.5)
ax.set_yticks(range(n)); ax.set_yticklabels([f"{r.family} · {'big-move odds' if r.type=='MOVE' else 'direction'}" for r in rows][::-1], fontsize=9.5)
ax.set_xlabel("largest |z| in the family (higher = stronger apparent pattern)"); ax.set_title("Real patterns vs. what pure chance produces (300 shifted-label placebos)"); ax.grid(axis="y", visible=False)
ax.scatter([], [], color=BLUE, s=60, label="largest real |z|"); ax.hlines([], 0, 0, color=MUTED, lw=7, alpha=0.5, label="placebo: mean … 95th pct of the family's largest |z|"); ax.scatter([], [], marker="|", s=240, color=ORANGE, label="Bonferroni cut-off"); ax.legend(loc="lower right", fontsize=9)
note(fig, "Volatility-state patterns clear even the placebo's 95th percentile (5.6) by 2–3×; calendar clock too. Direction patterns clear it only modestly in LOC/CTX/FLOW. CAL·big-move placebo is invalid (a time shift just relocates the clock effect), so Bonferroni only.", y=-0.01)
save(fig, "F13_placebo_calibration")
# ---------- F15 AUC ranking
A = pd.read_csv("AUC_single_feature.csv"); nmap = {"ln_range12": "range, last hour", "ln_range288": "range, last 24 h", "compress": "compression 1h/24h", "varratio": "acceleration 1h/24h", "pos24": "position in 24 h range", "pos7d": "position in 7 d range", "dayopen_z": "move since UTC day open", "weekopen_z": "move since week open", "round_dist": "distance to round number", "ctx12": "change, last 1 h", "ctx48": "change, last 4 h", "ctx288": "change, last 24 h", "ctx2016": "change, last 7 d", "VR": "volume vs same hour", "ABS": "volume per unit range", "TI12": "taker imbalance 1 h", "TI48": "taker imbalance 4 h", "TI288": "taker imbalance 24 h"}
A["name"] = A.feature.map(nmap)
fig, axs = plt.subplots(1, 2, figsize=(14, 6.2), sharey=False)
a1 = A.assign(d=(A.AUC_move_L2_adj - 0.5).abs()).sort_values("d"); a2 = A.assign(d=(A.AUC_dir_L2 - 0.5).abs()).sort_values("d")
axs[0].barh(a1.name, a1.AUC_move_L2_adj - 0.5, left=0.5, color=BLUE, height=0.6); axs[0].axvline(0.5, color=INK2, lw=1); axs[0].set_xlim(0.38, 0.72); axs[0].set_title("Can it tell WHEN? (big move yes/no)")
axs[1].barh(a2.name, a2.AUC_dir_L2 - 0.5, left=0.5, color=VIOLET, height=0.6); axs[1].axvline(0.5, color=INK2, lw=1); axs[1].set_xlim(0.38, 0.72); axs[1].set_title("Can it tell WHICH WAY? (up vs down, given a move)")
for a in axs: a.set_xlabel("AUC (0.5 = coin flip)"); a.grid(axis="y", visible=False)
note(fig, "Single-feature AUC for ≥2% in 8 h, computed within year × hour-of-day strata (so clock and regime are already removed). Best 'when' lens: range of the last hour (0.68); best 'which way': position in the 24 h range (0.53) and 24 h taker imbalance (0.55). Features are not combined (project rule).", y=-0.01)
save(fig, "F15_auc_ranking")
