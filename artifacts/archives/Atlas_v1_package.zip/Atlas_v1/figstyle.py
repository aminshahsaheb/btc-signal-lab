import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt, numpy as np
BLUE = "#2a78d6"; ORANGE = "#eb6834"; AQUA = "#1baf7a"; YELLOW = "#eda100"; MAG = "#e87ba4"; GREEN = "#008300"; VIOLET = "#6250d6"; RED = "#e34948"
INK = "#0b0b0b"; INK2 = "#52514e"; MUTED = "#898781"; GRID = "#e1e0d9"; AXIS = "#c3c2b7"; SURF = "#fcfcfb"
UPC, DNC = BLUE, ORANGE
plt.rcParams.update({"figure.facecolor": SURF, "axes.facecolor": SURF, "savefig.facecolor": SURF, "axes.edgecolor": AXIS, "axes.labelcolor": INK2,
    "xtick.color": MUTED, "ytick.color": MUTED, "text.color": INK, "axes.titlecolor": INK, "font.size": 10, "axes.titlesize": 11.5, "axes.titleweight": "semibold",
    "axes.titlelocation": "left", "axes.spines.top": False, "axes.spines.right": False, "axes.grid": True, "grid.color": GRID, "grid.linewidth": 0.8,
    "axes.axisbelow": True, "legend.frameon": False, "lines.linewidth": 2, "lines.solid_capstyle": "round", "font.family": "DejaVu Sans"})
def save(fig, name):
    fig.savefig(f"figs/{name}.png", dpi=130, bbox_inches="tight"); plt.close(fig); print("saved", name)
def note(fig, txt, y=-0.01):
    fig.text(0.01, y, txt, ha="left", va="top", fontsize=8.5, color=INK2, wrap=True)
