import numpy as np, pandas as pd, json, warnings
from figstyle import *
import common
warnings.filterwarnings("ignore"); common.check_plan()
T = pd.read_csv("atlas_tiers.csv"); ci_ = lambda r: (np.exp(np.log(r.lift) - 1.96 * r.se), np.exp(np.log(r.lift) + 1.96 * r.se))
yrs = [2021, 2022, 2023, 2024, 2025, 2026]
# ---------- F4 volatility / volume bins -> MOVE odds
feats = [("ln_range12", "Range of the last hour"), ("ln_range288", "Range of the last 24 h"), ("compress", "Compression: 1 h range vs 24 h range"),
         ("varratio", "Acceleration: 1 h variance vs 24 h variance"), ("VR", "Volume vs same hour, prior 8 weeks"), ("ABS", "Volume per unit of range")]
fig, axs = plt.subplots(2, 3, figsize=(14, 7.6), sharey=True); fig.subplots_adjust(hspace=0.42, top=0.9)
for ax, (f, ttl) in zip(axs.ravel(), feats):
    rows = [T[(T.outcome == "MOVE_L2") & (T.cell == f"{f}_b{k}")].iloc[0] for k in range(5)]
    for k, r in enumerate(rows):
        lo, hi = ci_(r)
        ax.bar(k, r.lift, width=0.55, color=BLUE, alpha=0.9)
        ax.vlines(k, lo, hi, color=INK, lw=1.2)
        ax.scatter([k] * 6, [r[f"y{y}"] for y in yrs], s=12, color=MUTED, zorder=4, edgecolor=SURF, linewidth=0.6)
        ax.text(k, max(hi, r.lift) * 1.06, f"{r.lift:.2f}", ha="center", fontsize=8.5, color=INK2)
    ax.axhline(1, color=INK2, lw=1); ax.set_yscale("log"); ax.set_ylim(0.3, 2.6); ax.set_yticks([0.4, 0.6, 1, 1.5, 2.5]); ax.get_yaxis().set_major_formatter(matplotlib.ticker.FuncFormatter(lambda v, _: f"{v:g}")); ax.yaxis.set_minor_formatter(matplotlib.ticker.NullFormatter()); ax.yaxis.set_minor_locator(matplotlib.ticker.NullLocator())
    ax.set_xticks(range(5)); ax.set_xticklabels(["lowest\n20%", "", "middle", "", "highest\n20%"], fontsize=8.5); ax.set_title(ttl, fontsize=10.5)
axs[0, 0].set_ylabel("lift on P(≥2% move in 8 h)"); axs[1, 0].set_ylabel("lift on P(≥2% move in 8 h)")
fig.suptitle("What the market 'looks like' before a move: volatility and volume state (probability of a ≥2% move within 8 h)", x=0.01, ha="left", fontsize=13, fontweight="semibold", y=1.0)
note(fig, "Bars = lift vs. a calendar- and year-adjusted baseline (1.0 = typical); whisker = approx 95% band (week-clustered); grey dots = each year 2021…2026 (all six move the same way). Bins from 2021–2023 quantiles. These are the same phenomenon seen through different features (volatility clusters); they say WHEN, not WHICH WAY.", y=-0.01)
save(fig, "F04_vol_volume_bins")
# ---------- F5 direction by bins
dfeats = [("pos24", "Position inside the 24 h range"), ("pos7d", "Position inside the 7-day range"), ("ctx48", "Price change of last 4 h (vol-scaled)"),
          ("ctx288", "Price change of last 24 h (vol-scaled)"), ("TI48", "Taker buy-vs-sell imbalance, last 4 h"), ("TI288", "Taker buy-vs-sell imbalance, last 24 h")]
fig, axs = plt.subplots(2, 3, figsize=(14, 7.6), sharey=True); fig.subplots_adjust(hspace=0.42, top=0.9)
for ax, (f, ttl) in zip(axs.ravel(), dfeats):
    ax.axhspan(-3, 3, color=GRID, alpha=0.6, lw=0)
    for L, col, nm, off in (("L1", AQUA, "≥1% in 2 h", -0.12), ("L2", VIOLET, "≥2% in 8 h", 0.12)):
        rr = [T[(T.outcome == f"DIR_{L}") & (T.cell == f"{f}_b{k}")].iloc[0] for k in range(5)]
        ys = np.array([r.pp * 100 for r in rr]); es = np.array([1.96 * r.se * 100 for r in rr])
        ax.errorbar(np.arange(5) + off, ys, yerr=es, fmt="o-", color=col, ms=6, lw=1.6, capsize=2.5, mec=SURF, mew=1.5, label=nm)
    ax.axhline(0, color=INK2, lw=1); ax.set_xticks(range(5)); ax.set_xticklabels(["lowest\n20%", "", "middle", "", "highest\n20%"], fontsize=8.5); ax.set_title(ttl, fontsize=10.5); ax.set_ylim(-14, 14)
axs[0, 0].set_ylabel("UP-share minus baseline (pp)"); axs[1, 0].set_ylabel("UP-share minus baseline (pp)"); axs[0, 0].legend(loc="upper left", fontsize=9)
fig.suptitle("Given that a big move starts — is it UP or DOWN?  Direction lean by market state", x=0.01, ha="left", fontsize=13, fontweight="semibold", y=1.0)
note(fig, "Grey band = ±3 pp, my pre-set 'material' threshold. Dots = lean in the share of UP-first moves (0 = 50/50 once year-level drift is removed). Whiskers ≈ 95%. Every state leans the same way: toward CONTINUATION of what just happened (high = UP, low = DOWN), small (4–8 pp at 2 h, 3–8 pp at 8 h), same sign in all years and all three periods. It is one factor seen through six lenses, and the ledger already closed momentum / taker-imbalance as strategies.", y=-0.01)
save(fig, "F05_direction_by_bins")
# ---------- F6 events
names = []
for t in ("BREAK_UP", "BREAK_DN", "SWEEP_UP", "SWEEP_DN"):
    for N in (48, 288, 2016, 8640): names.append(f"{t}_{N}")
names += ["BOUNCE_UP", "BOUNCE_DN", "NR24", "WR24"]
lab = {"BREAK_UP": "close above prior high", "BREAK_DN": "close below prior low", "SWEEP_UP": "wick above prior high, close back inside", "SWEEP_DN": "wick below prior low, close back inside"}
win = {48: "4 h", 288: "24 h", 2016: "7 d", 8640: "30 d"}
def nm(c):
    if c in ("BOUNCE_UP", "BOUNCE_DN"): return "bounce ≥1% off 24h low" if c.endswith("UP") else "drop ≥1% off 24h high"
    if c == "NR24": return "narrowest 1 h range of last 24 h"
    if c == "WR24": return "widest 1 h range of last 24 h"
    t, N = c.rsplit("_", 1); return f"{lab[t]}  ({win[int(N)]})"
fig, axs = plt.subplots(1, 2, figsize=(15, 8.4), sharey=True, gridspec_kw=dict(width_ratios=[1, 1.05]))
yy = np.arange(len(names))[::-1]
def col(c):
    p = c.split("_")
    return UPC if (len(p) > 1 and p[1] == "UP") or c == "WR24" else (DNC if (len(p) > 1 and p[1] == "DN") or c == "NR24" else MUTED)
for y, c in zip(yy, names):
    r = T[(T.outcome == "MOVE_L2") & (T.cell == c)].iloc[0]; lo, hi = ci_(r)
    axs[0].barh(y, r.lift - 1, left=1, height=0.55, color=col(c)); axs[0].hlines(y, lo, hi, color=INK, lw=1.2)
    for L, cc, off in (("L1", AQUA, 0.17), ("L2", VIOLET, -0.17)):
        d = T[(T.outcome == f"DIR_{L}") & (T.cell == c)].iloc[0]
        axs[1].errorbar(d.pp * 100, y + off, xerr=1.96 * d.se * 100, fmt="o", color=cc, ms=5.5, lw=1.4, capsize=2, mec=SURF, mew=1.2, label={"L1": "≥1% in 2 h", "L2": "≥2% in 8 h"}[L] if c == names[0] else None)
axs[0].set_xscale("log"); axs[0].set_xlim(0.5, 3.2); axs[0].axvline(1, color=INK2, lw=1); axs[0].set_xticks([0.5, 0.7, 1, 1.5, 2, 3]); axs[0].get_xaxis().set_major_formatter(matplotlib.ticker.FuncFormatter(lambda v, _: f"{v:g}")); axs[0].xaxis.set_minor_formatter(matplotlib.ticker.NullFormatter()); axs[0].xaxis.set_minor_locator(matplotlib.ticker.NullLocator())
axs[0].set_yticks(yy); axs[0].set_yticklabels([nm(c) for c in names], fontsize=8.5); axs[0].set_xlabel("lift on P(≥2% move in 8 h)"); axs[0].set_title("Does the event make a big move MORE likely?")
axs[1].axvspan(-3, 3, color=GRID, alpha=0.6, lw=0); axs[1].axvline(0, color=INK2, lw=1); axs[1].set_xlim(-18, 18); axs[1].set_xlabel("UP-share minus baseline (pp)"); axs[1].set_title("…and does it say WHICH WAY?"); axs[1].legend(loc="lower right", fontsize=9)
for a in axs: a.grid(axis="y", visible=False)
note(fig, "Blue = upside event, orange = downside event. Left: every break/sweep/bounce raises the odds of a big move, and DOWNSIDE breaks of long lookbacks raise them most (7 d low break ≈ 1.8×; 30 d ≈ 2.4×) — a leverage/liquidation-type asymmetry. Right: the direction after the event barely leans (grey band = ±3 pp 'material'); sweeps lean toward continuation, not reversal.", y=0.04)
save(fig, "F06_events")
# ---------- F7 event study
E = pd.read_csv("D6_event_study.csv"); colr = {"UP": UPC, "DOWN": DNC, "NONE": MUTED}
fig, axs = plt.subplots(2, 2, figsize=(14, 8.6)); fig.subplots_adjust(hspace=0.38, top=0.92)
for g in ("NONE", "UP", "DOWN"):
    d = E[E.group == g]; lw = 2 if g != "NONE" else 1.5
    axs[0, 0].plot(d.m_hours, d["mean"], color=colr[g], lw=lw, label=f"{g} (n={int(d.n.iloc[0]):,})"); axs[0, 0].fill_between(d.m_hours, d.lo, d.hi, color=colr[g], alpha=0.15, lw=0)
    p = d[d.m_hours <= 0]; axs[0, 1].plot(p.m_hours, p["mean"], color=colr[g], lw=lw); axs[0, 1].fill_between(p.m_hours, p.lo, p.hi, color=colr[g], alpha=0.15, lw=0)
    axs[1, 0].plot(d.m_hours, np.exp(d.ln_range12) * 100, color=colr[g], lw=lw)
    axs[1, 1].plot(d.m_hours, d.VR, color=colr[g], lw=lw)
for a in axs.ravel(): a.axvline(0, color=INK2, lw=0.8); a.set_xlabel("hours from decision time")
axs[0, 0].axhline(0, color=INK2, lw=0.8); axs[0, 1].axhline(0, color=INK2, lw=0.8)
axs[0, 0].set_title("Average price path (in units of normal 24 h volatility)"); axs[0, 0].legend(loc="upper left", fontsize=9); axs[0, 0].set_ylabel("σ units")
axs[0, 1].set_title("Zoom on the 48 h BEFORE the decision"); axs[0, 1].set_ylabel("σ units")
axs[1, 0].set_title("Typical 1 h range going in and out (% of price)"); axs[1, 0].set_ylabel("%")
axs[1, 1].set_title("Volume vs same hour in prior 8 weeks (log ratio)"); axs[1, 1].set_ylabel("log ratio")
fig.suptitle("Event study: hours that start an UP move, a DOWN move, or nothing (≥2% within 8 h)", x=0.01, ha="left", fontsize=13, fontweight="semibold", y=1.0)
note(fig, "Positive value before 0 = price was higher earlier, i.e. had been FALLING into the decision hour. DOWN-starts are preceded by a decline of ~0.1–0.15σ; UP-starts by the same mild rise as ordinary hours (grey). The lead-in is under a fifth of the move that follows and leans toward continuation, matching the direction lean in F05; range and volume are already elevated for BOTH. Shaded = approx 95% band (week-block bootstrap).", y=-0.01)
save(fig, "F07_event_study")
