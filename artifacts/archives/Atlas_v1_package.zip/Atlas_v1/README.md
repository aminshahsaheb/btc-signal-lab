# Move-Onset Atlas v1 — BTCUSDT 5m, 2021-01-01 → 2026-09-22

STATUS: descriptive atlas, NOT ledger evidence. Data are burned (already seen); no cell here is a validated edge.
Single-feature cells only (no combined states, no OI) — see PLAN.md / PLAN_ERRATA.md (locked, SHA-256 in PLAN.sha256).

## Read first
- atlas_tiers.csv        all 984 tests (164 cells x 6 outcomes) with z, lift, per-year / per-period values, tier (A / B / report-only / -)
- placebo_summary.csv    placebo calibration per family (300 circular label shifts); CAL*MOVE placebo invalid -> Bonferroni only
- figs/F01..F15 (PNG)    figures used in the report (F12 = two galleries)
- D*.csv, AUC_single_feature.csv   descriptive modules (weekend-gap proxy, timing, concentration, pivots, real-time 2:1 view, event study, gallery, onsets)
- verification/          independent re-implementation (written from PLAN.md only) and comparison table

## Labels
L1 = first close-breach of +-1% within 24 bars (2h), L2 = +-2% within 96 bars (8h, ledger target), L3 = +-3% within 288 bars (24h).
Decision points = every full UTC hour (minute-55 bar close). Splits: DISC < 2024-01-01, CONF 2024-01-01..2025-01-06, HOLD >= 2025-01-07.

## Re-run order (python3, needs ../pkg_data.csv, sha256 prefix 0bea138cc96dfec0; scripts refuse to run if PLAN.md hash changed)
build.py -> test_engine.py, test_stats.py -> run_main.py -> run_placebo.py -> tiers.py -> desc1.py, desc2.py, desc3.py -> figs1.py ... figs4.py

## Known limits
~1 month missing (2026-09-23..10-25); only OHLCV + taker_buy_base; no funding / OI / basis / CME prices; weekend "CME gap" is a Binance proxy
(CME announced 24/7 crypto futures from 2026-05-29). Direction-test SE has variants: z can move by up to ~0.6 -> borderline cells are hints.
